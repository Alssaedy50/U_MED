# TeleDrive MTProto — Cloud-Native Telegram to Google Drive Bridge & Workbench

A production-ready Python MTProto automation engine (`Pyrogram` + `Google Drive API v3` + `aiohttp`) accompanied by an interactive developer workbench for configuring environment variables, encoding Google Service Account JSON keys into Base64, inspecting generated source deliverables, and exporting a ready-to-deploy repository archive.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and product choices have been confirmed from your answers and are baked into this blueprint:

- **Google Drive Authentication**: Uses a **Google Service Account JSON encoded in Base64** (`GDRIVE_CREDENTIALS_B64`), decoded in-memory at runtime so secret JSON files are never committed to GitHub or baked into Docker layers.
- **Telegram Access Control**: Enforces strict authorization via an **`AUTHORIZED_USER_IDS`** environment variable (comma-separated Telegram User IDs) alongside private chat filtering (`filters.private & (filters.document | filters.video | filters.audio)`), while supporting both `BOT_TOKEN` and `SESSION_STRING` (MTProto UserBot) authentication modes.
- **Interactive Web Companion**: Provides an **Interactive Configurator, Code Inspector, and One-Click ZIP Exporter** so you can customize chunk sizes, flood-wait intervals, folder IDs, and Base64 credentials directly in the browser, inspect every generated deliverable (`requirements.txt`, `config.py`, `gdrive.py`, `main.py`, `Dockerfile`, `.gitignore`, `README.md`), and download either individual files or the complete deployment bundle.

---

## 1. Overview & Core Concept

- **What It Does**: Delivers a complete, modular Python 3.10+ application that bypasses the standard 20MB Telegram HTTP Bot API limit using native MTProto (`Pyrogram` + `tgcrypto`) to stream files up to 2GB (or 4GB with Telegram Premium UserBot sessions) directly to Google Drive using chunked resumable uploads (`MediaFileUpload`), paired with an `aiohttp` health-check server on port `7860` for 24/7 hosting on Hugging Face Spaces or Docker platforms.
- **Target Audience / Persona**: Cloud and systems engineers deploying personal or team media/document archival pipelines onto free container environments without risking disk saturation or secret leakage.
- **Key Value**: Guaranteed zero-disk-leak cleanup via `try...finally` file removal, flood-wait-safe live progress updates throttled to 4.5-second intervals, and an interactive browser workbench that validates configurations and generates ready-to-commit deployment artifacts.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Configure Runtime Parameters**: Adjust MTProto authentication mode (Bot Token vs. UserBot Session String), upload chunk size (10MB / 20MB / 50MB), progress throttle interval (4–5s), target `GDRIVE_FOLDER_ID`, and `AUTHORIZED_USER_IDS` in the left configuration panel; changes dynamically update the generated Python code and `.env` template.
  2. **Encode Service Account JSON**: Paste or drag-and-drop a Google Cloud `service_account.json` file into the built-in client-side Base64 Encoder utility to validate required fields (`client_email`, `private_key`, `project_id`), view the service account email to share your Google Drive folder with, and copy the `GDRIVE_CREDENTIALS_B64` secret string.
  3. **Inspect & Copy Deliverables**: Switch across the 7 required project deliverables (`requirements.txt`, `config.py`, `gdrive.py`, `main.py`, `Dockerfile`, `.gitignore`, `README.md`) with syntax-highlighted code inspection, line numbers, architectural annotations, and one-click copy or individual file download.
  4. **Verify Transfer Pipeline & Export ZIP**: Test the flood-wait-throttled progress bar formatting and `try...finally` lifecycle in the interactive transfer simulator, or click **Export Project ZIP** to download the entire repository ready for `git push` to GitHub or Hugging Face Spaces.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Precision Developer Console & Cloud Systems Workbench — high-contrast dark slate surfaces, crisp 1px structural hairlines, and zero decorative clutter.
  - *Color Palette & Mood*:
    - **60% Dominant Canvas**: Deep Slate `#0B0F17` (`bg-slate-950`) with crisp `#F8FAFC` (`text-slate-50`) primary typography.
    - **30% Structural Surfaces**: Elevated panel slate `#111827` (`bg-slate-900`) and subtle `1px solid` borders (`border-slate-800`), paired with muted metadata text `#94A3B8` (`text-slate-400`).
    - **10% Accent Budget**: Sky Blue `#0EA5E9` (`bg-sky-500` / `text-sky-400`) for primary actions and active file tabs, paired with semantic Emerald `#10B981` for verified configuration states and Amber `#F59E0B` for storage/permission warnings.
  - *Typography & Hierarchy*:
    - **Display & UI Structure**: `Plus Jakarta Sans` (SemiBold 600 / Bold 700) for clean headers and workspace navigation.
    - **Body & Documentation**: `Public Sans` (Regular 400 / Medium 500) for high-legibility technical explanations.
    - **Code, Sizes & Telemetry**: `JetBrains Mono` with `tabular-nums` for all Python source views, byte/MB calculations, port numbers (`7860`), and UID (`1000`) specifications.
  - *Component Styling & Layout*: Full 1440px desktop split-pane layout featuring a 3-zone top bar contract, a left-hand parameter & Base64 credential studio (`380px` width), and a right-hand multi-tab code inspector and deployment verification canvas. Single-elevation depth with hairline dividers and unboxed metadata separated by `·`.

- **Interactive Feedback & Motion**: Instant `<150ms` tab transitions, copy-to-clipboard confirmation states, live JSON validation feedback when encoding Service Account credentials, and interactive chunked transfer simulation.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Blocking Google API Calls Wrapped in `asyncio.to_thread`**
  - *Chosen Approach*: The `google-api-python-client` library uses synchronous `httplib2` sockets under the hood. In `gdrive.py` and `main.py`, each `request.next_chunk()` call is executed safely via `asyncio.to_thread` (or an executor loop) while reporting chunk progress back to the async event loop.
  - *Why*: Ensures the `aiohttp` health-check server on port `7860` and the `Pyrogram` MTProto heartbeat never block or time out during multi-gigabyte uploads.
  - *Alternatives Considered*: Running synchronous `next_chunk()` directly inside the Pyrogram handler, which freezes the event loop and causes Hugging Face health probes to fail.

- **Decision 2: Strict `try...finally` Ephemeral Disk Hygiene**
  - *Chosen Approach*: Every incoming media transfer downloads to a dedicated `/tmp/downloads` directory inside a `try` block, uploads in 10MB/20MB chunks to Google Drive, and guarantees `os.remove(file_path)` execution inside the `finally` block even if an upload or Telegram API call raises an exception.
  - *Why*: Free container environments have strict ephemeral storage limits; a single orphaned 1.8GB video file can crash the container on subsequent runs.

- **Decision 3: Dual Auth Support (`BOT_TOKEN` or `SESSION_STRING`) + User ID Allowlist**
  - *Chosen Approach*: `config.py` and `main.py` support initializing the `pyrogram.Client` with either a `BOT_TOKEN` or an MTProto `SESSION_STRING` (UserBot), gated by a custom filter checking `AUTHORIZED_USER_IDS`.
  - *Why*: Meets the requirement to support automated Bot Token or MTProto UserBot Session String via environment variables while protecting personal Google Drive quota from unauthorized users.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                   TeleDrive MTProto Workbench (Web UI)                       │
│  ┌────────────────────────────┐   ┌───────────────────────────────────────┐  │
│  │ Runtime Config & Base64    │   │ Deliverable Inspector & ZIP Builder   │  │
│  │ Credential Studio          │──▶│ • requirements.txt  • config.py       │  │
│  │ • Auth Mode (Bot/Session)  │   │ • gdrive.py         • main.py         │  │
│  │ • Chunk Size (10MB/20MB)   │   │ • Dockerfile        • .gitignore      │  │
│  │ • Service Account Encoder  │   │ • README.md         • .env.example    │  │
│  └────────────────────────────┘   └───────────────────────────────────────┘  │
└───────────────────────────────────────────────┬──────────────────────────────┘
                                                │ Generates & Packages
                                                ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│            Generated Python Container Runtime (UID 1000, Port 7860)          │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                     Single Asyncio Event Loop (main.py)                │  │
│  │                                                                        │  │
│  │  ┌─────────────────────────┐        ┌───────────────────────────────┐  │  │
│  │  │ aiohttp Web Server      │        │ Pyrogram MTProto Client       │  │  │
│  │  │ GET / & /health -> 200  │        │ Filter: Private + Auth Users  │  │  │
│  │  │ Port: 7860              │        │ Media: Document | Video | Aud │  │  │
│  │  └─────────────────────────┘        └──────────────┬────────────────┘  │  │
│  │                                                    │                   │  │
│  │                                     1. Stream Download (4.5s throttle) │  │
│  │                                                    ▼                   │  │
│  │                                     ┌───────────────────────────────┐  │  │
│  │                                     │ Ephemeral Storage (/tmp/dl)   │  │  │
│  │                                     └──────────────┬────────────────┘  │  │
│  │                                                    │                   │  │
│  │                                     2. Resumable Upload (10-20MB)      │  │
│  │                                                    ▼                   │  │
│  │                                     ┌───────────────────────────────┐  │  │
│  │                                     │ GoogleDriveUploader (gdrive)  │  │  │
│  │                                     │ • Base64 Service Account Auth │  │  │
│  │                                     │ • MediaFileUpload (resumable) │  │  │
│  │                                     │ • Returns webViewLink         │  │  │
│  │                                     └──────────────┬────────────────┘  │  │
│  │                                                    │                   │  │
│  │                                     3. finally: os.remove(file_path)   │  │
│  └────────────────────────────────────────────────────┴───────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Deliverable Specifications

1. **`requirements.txt`**: Pinned production versions for `pyrogram==2.0.106`, `tgcrypto==1.2.5`, `google-api-python-client==2.149.0`, `google-auth==2.35.0`, `google-auth-httplib2==0.2.0`, `google-auth-oauthlib==1.2.1`, and `aiohttp==3.10.10`.
2. **`config.py`**: Strictly reads `API_ID`, `API_HASH`, `BOT_TOKEN`, `SESSION_STRING`, `GDRIVE_FOLDER_ID`, `GDRIVE_CREDENTIALS_B64` (with fallback support for raw `SERVICE_ACCOUNT_JSON`), `AUTHORIZED_USER_IDS`, `UPLOAD_CHUNK_SIZE_MB`, and `PORT` (default `7860`), raising clear startup validation errors if required credentials are missing.
3. **`gdrive.py`**: Implements `GoogleDriveClient` that decodes `GDRIVE_CREDENTIALS_B64` into a `service_account.Credentials` object in-memory, executes `MediaFileUpload(..., chunksize=chunk_bytes, resumable=True)`, invokes an async-compatible progress callback after each chunk, optionally applies reader permissions if configured, and returns `{id, name, size, webViewLink, webContentLink}`.
4. **`main.py`**: Runs the `aiohttp` server (`0.0.0.0:7860`) and the `Pyrogram` client concurrently inside `asyncio.run(main())`, handles `(filters.document | filters.video | filters.audio) & filters.private`, enforces `AUTHORIZED_USER_IDS`, updates a human-readable progress bar (`percentage`, `transferred/total MB`, `speed`, `ETA`) throttled every 4.5 seconds with `FloodWait` handling, uploads to Google Drive, replies with the formatted `webViewLink`, and guarantees local file deletion inside `finally:`.
5. **`Dockerfile`**: Built on `python:3.10-slim`, installs `gcc` for `tgcrypto` compilation if needed, creates a non-root `user` with `UID 1000` (required by Hugging Face Spaces), sets `HOME=/home/user`, exposes port `7860`, and launches `python main.py`.
6. **`.gitignore` & `README.md`**: Excludes `*.session`, `*.session-journal`, `downloads/`, `.env`, and credential JSON files; provides step-by-step instructions for encoding the Service Account JSON, sharing the target Google Drive folder with the Service Account email, and deploying to Hugging Face Spaces or Docker.

### Interactive Component & State Mapping

- **Configuration Studio State**: Updating chunk size (`10MB` / `20MB`), flood-wait edit interval (`4.5s`), default folder behavior, or auth mode immediately synchronizes the code templates and `.env.example` preview.
- **Service Account Base64 Utility**: Parses uploaded or pasted JSON locally in the browser, extracts `client_email` so the user can copy it to share their Google Drive folder, and outputs the exact `GDRIVE_CREDENTIALS_B64` string.
- **ZIP Archive Generator**: Pure client-side ZIP binary builder (or `jszip` integration) that packages all 7 deliverables with proper UNIX permissions and directory layout into a single `teledrive-mtproto-bot.zip` download.
