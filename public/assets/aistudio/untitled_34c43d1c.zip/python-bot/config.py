"""
Centralized configuration module for the Telegram-to-Google-Drive MTProto Bot.
Reads all settings strictly from environment variables to ensure zero secrets
are ever hardcoded or committed to version control.
"""

import base64
import json
import logging
import os
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, Set

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger("teledrive.config")


def _parse_authorized_users(raw_value: str) -> Set[int]:
    """Parse a comma-separated list of integer Telegram User IDs."""
    user_ids: Set[int] = set()
    if not raw_value or not raw_value.strip():
        return user_ids
    for token in raw_value.split(","):
        cleaned = token.strip()
        if not cleaned:
            continue
        try:
            user_ids.add(int(cleaned))
        except ValueError as exc:
            raise ValueError(
                f"Invalid Telegram User ID '{cleaned}' in AUTHORIZED_USER_IDS. Must be integer."
            ) from exc
    return user_ids


def _load_service_account_info() -> Dict[str, Any]:
    """
    Decode Google Service Account credentials from GDRIVE_CREDENTIALS_B64
    (Base64-encoded JSON) or fallback to raw SERVICE_ACCOUNT_JSON env var.
    """
    b64_creds = os.environ.get("GDRIVE_CREDENTIALS_B64", "").strip()
    raw_json = os.environ.get("SERVICE_ACCOUNT_JSON", "").strip()

    if b64_creds:
        try:
            decoded_bytes = base64.b64decode(b64_creds)
            creds_dict = json.loads(decoded_bytes.decode("utf-8"))
        except Exception as exc:
            raise ValueError(
                "Failed to decode GDRIVE_CREDENTIALS_B64. Ensure it is valid Base64-encoded JSON."
            ) from exc
    elif raw_json:
        try:
            creds_dict = json.loads(raw_json)
        except Exception as exc:
            raise ValueError(
                "Failed to parse SERVICE_ACCOUNT_JSON. Ensure it contains valid JSON."
            ) from exc
    else:
        raise EnvironmentError(
            "Missing Google Drive credentials. Set GDRIVE_CREDENTIALS_B64 (recommended) "
            "or SERVICE_ACCOUNT_JSON in your environment variables."
        )

    required_keys = {"type", "project_id", "private_key", "client_email"}
    missing = required_keys - set(creds_dict.keys())
    if missing:
        raise ValueError(
            f"Service Account JSON is missing required fields: {', '.join(sorted(missing))}"
        )

    return creds_dict


@dataclass(frozen=True)
class Config:
    """Immutable runtime configuration loaded from environment variables."""

    # Telegram MTProto Credentials
    api_id: int
    api_hash: str
    bot_token: Optional[str] = None
    session_string: Optional[str] = None

    # Access Control (Restricted to authorized user IDs via env var)
    authorized_user_ids: Set[int] = field(default_factory=set)

    # Google Drive Settings
    gdrive_folder_id: Optional[str] = None
    service_account_info: Dict[str, Any] = field(default_factory=dict)
    share_anyone_with_link: bool = False

    # Transfer & Memory Safety Settings
    upload_chunk_size_mb: int = 20
    progress_update_interval_sec: float = 4.5
    download_dir: str = "/tmp/teledrive_downloads"

    # Container Health Check Server
    port: int = 7860
    host: str = "0.0.0.0"

    @property
    def upload_chunk_size_bytes(self) -> int:
        """Return resumable upload chunk size in bytes (must be multiple of 256 KB)."""
        return self.upload_chunk_size_mb * 1024 * 1024


def load_config() -> Config:
    """Validate and load all configuration parameters from environment variables."""
    api_id_raw = os.environ.get("API_ID", "").strip()
    if not api_id_raw:
        raise EnvironmentError("Missing required environment variable: API_ID")
    try:
        api_id = int(api_id_raw)
    except ValueError as exc:
        raise ValueError("API_ID must be a valid integer from my.telegram.org") from exc

    api_hash = os.environ.get("API_HASH", "").strip()
    if not api_hash:
        raise EnvironmentError("Missing required environment variable: API_HASH")

    bot_token = os.environ.get("BOT_TOKEN", "").strip() or None
    session_string = os.environ.get("SESSION_STRING", "").strip() or None

    if not bot_token and not session_string:
        raise EnvironmentError(
            "Authentication required: Provide either BOT_TOKEN (for automated bot) "
            "or SESSION_STRING (for MTProto UserBot) in environment variables."
        )

    authorized_users = _parse_authorized_users(
        os.environ.get("AUTHORIZED_USER_IDS", "")
    )
    if not authorized_users:
        logger.warning(
            "AUTHORIZED_USER_IDS is empty. For security, set a comma-separated list "
            "of Telegram User IDs allowed to transfer files."
        )

    gdrive_folder_id = os.environ.get("GDRIVE_FOLDER_ID", "").strip() or None
    service_account_info = _load_service_account_info()

    share_anyone = os.environ.get("GDRIVE_PUBLIC_LINK", "false").strip().lower() in {
        "1",
        "true",
        "yes",
    }

    chunk_mb = int(os.environ.get("UPLOAD_CHUNK_SIZE_MB", "20").strip())
    if chunk_mb not in {5, 10, 20, 50}:
        chunk_mb = 20

    progress_interval = float(
        os.environ.get("PROGRESS_UPDATE_INTERVAL", "4.5").strip()
    )
    if progress_interval < 3.0:
        progress_interval = 4.5

    port = int(os.environ.get("PORT", "7860").strip())
    download_dir = os.environ.get("DOWNLOAD_DIR", "/tmp/teledrive_downloads").strip()
    os.makedirs(download_dir, exist_ok=True)

    return Config(
        api_id=api_id,
        api_hash=api_hash,
        bot_token=bot_token,
        session_string=session_string,
        authorized_user_ids=authorized_users,
        gdrive_folder_id=gdrive_folder_id,
        service_account_info=service_account_info,
        share_anyone_with_link=share_anyone,
        upload_chunk_size_mb=chunk_mb,
        progress_update_interval_sec=progress_interval,
        download_dir=download_dir,
        port=port,
    )
