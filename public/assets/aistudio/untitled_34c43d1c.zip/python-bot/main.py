"""
Core entrypoint for the Personal Telegram-to-Google-Drive MTProto Bot.
Runs both an aiohttp health-check web server (Port 7860 for Hugging Face Spaces)
and the Pyrogram MTProto client concurrently within a single asyncio event loop.
"""

import asyncio
import logging
import math
import os
import time
from typing import Optional

from aiohttp import web
from pyrogram import Client, filters, idle
from pyrogram.errors import FloodWait, MessageNotModified
from pyrogram.types import Message

from config import Config, load_config
from gdrive import GoogleDriveUploader

logger = logging.getLogger("teledrive.main")


def format_bytes(size_bytes: float) -> str:
    """Convert raw bytes into a human-readable string (KB, MB, GB)."""
    if size_bytes <= 0:
        return "0 B"
    units = ("B", "KB", "MB", "GB", "TB")
    index = int(math.floor(math.log(size_bytes, 1024)))
    index = min(index, len(units) - 1)
    value = size_bytes / math.pow(1024, index)
    return f"{value:.2f} {units[index]}"


def format_duration(seconds: float) -> str:
    """Format remaining seconds into a concise human-readable ETA."""
    if seconds <= 0 or math.isinf(seconds) or math.isnan(seconds):
        return "0s"
    total_secs = int(round(seconds))
    mins, secs = divmod(total_secs, 60)
    hours, mins = divmod(mins, 60)
    if hours > 0:
        return f"{hours}h {mins}m {secs}s"
    if mins > 0:
        return f"{mins}m {secs}s"
    return f"{secs}s"


def render_progress_bar(percentage: float, length: int = 12) -> str:
    """Render a clean ASCII progress bar for Telegram status messages."""
    clamped = max(0.0, min(100.0, percentage))
    filled = int(round((clamped / 100.0) * length))
    return "█" * filled + "░" * (length - filled)


class ThrottledProgressTracker:
    """
    Throttles Telegram edit_message_text calls to once every 4-5 seconds
    to prevent FloodWait limits while transferring multi-gigabyte files.
    """

    def __init__(
        self,
        status_message: Message,
        filename: str,
        stage_title: str,
        min_interval_sec: float = 4.5,
    ) -> None:
        self.status_message = status_message
        self.filename = filename
        self.stage_title = stage_title
        self.min_interval_sec = min_interval_sec
        self.start_time = time.monotonic()
        self.last_update_time = 0.0

    async def update(self, current_bytes: int, total_bytes: int) -> None:
        """Edit the Telegram status message if the throttle interval has elapsed."""
        now = time.monotonic()
        is_complete = total_bytes > 0 and current_bytes >= total_bytes

        if not is_complete and (now - self.last_update_time) < self.min_interval_sec:
            return

        self.last_update_time = now
        elapsed = max(0.001, now - self.start_time)
        speed_bps = current_bytes / elapsed
        percentage = (current_bytes / total_bytes * 100.0) if total_bytes > 0 else 0.0
        remaining_bytes = max(0, total_bytes - current_bytes)
        eta_seconds = (remaining_bytes / speed_bps) if speed_bps > 0 else 0.0

        bar = render_progress_bar(percentage)
        text = (
            f"**{self.stage_title}**\n\n"
            f"**File:** `{self.filename}`\n"
            f"**Progress:** `{bar}` `{percentage:.1f}%`\n"
            f"**Transferred:** `{format_bytes(current_bytes)} / {format_bytes(total_bytes)}`\n"
            f"**Speed:** `{format_bytes(speed_bps)}/s` · **ETA:** `{format_duration(eta_seconds)}`"
        )

        try:
            await self.status_message.edit_text(text, disable_web_page_preview=True)
        except MessageNotModified:
            pass
        except FloodWait as exc:
            logger.warning("Telegram FloodWait encountered: sleeping %d seconds", exc.value)
            await asyncio.sleep(exc.value)
        except Exception as exc:
            logger.debug("Non-fatal progress update error: %s", exc)


def extract_media_metadata(message: Message) -> tuple[str, int]:
    """Extract a safe filename and file size from a document, video, or audio message."""
    media = message.document or message.video or message.audio
    if media is None:
        raise ValueError("Message does not contain a supported media attachment.")

    file_size = getattr(media, "file_size", 0) or 0
    raw_name = getattr(media, "file_name", None)

    if not raw_name:
        ext = ".bin"
        mime = getattr(media, "mime_type", "") or ""
        if "mp4" in mime:
            ext = ".mp4"
        elif "mpeg" in mime or "mp3" in mime:
            ext = ".mp3"
        elif "pdf" in mime:
            ext = ".pdf"
        raw_name = f"telegram_{message.id}_{int(time.time())}{ext}"

    # Sanitize path separators to prevent directory traversal
    safe_name = os.path.basename(raw_name.replace("\\", "_").replace("/", "_"))
    return safe_name, file_size


async def start_health_server(config: Config) -> web.AppRunner:
    """Start a lightweight aiohttp web server on port 7860 returning 200 OK."""
    app = web.Application()

    async def handle_health(_request: web.Request) -> web.Response:
        return web.json_response(
            {
                "status": "OK",
                "service": "teledrive-mtproto-bot",
                "port": config.port,
            },
            status=200,
        )

    app.router.add_get("/", handle_health)
    app.router.add_get("/health", handle_health)
    app.router.add_get("/healthz", handle_health)

    runner = web.AppRunner(app, access_log=None)
    await runner.setup()
    site = web.TCPSite(runner, host=config.host, port=config.port)
    await site.start()
    logger.info("Health-check server listening on http://%s:%d", config.host, config.port)
    return runner


def build_pyrogram_client(config: Config) -> Client:
    """Initialize Pyrogram MTProto client via Bot Token or UserBot Session String."""
    if config.session_string:
        logger.info("Initializing Pyrogram MTProto client using SESSION_STRING (UserBot mode)")
        return Client(
            name="teledrive_userbot",
            api_id=config.api_id,
            api_hash=config.api_hash,
            session_string=config.session_string,
            in_memory=True,
            workers=4,
            max_concurrent_transmissions=2,
        )

    logger.info("Initializing Pyrogram MTProto client using BOT_TOKEN")
    return Client(
        name="teledrive_bot",
        api_id=config.api_id,
        api_hash=config.api_hash,
        bot_token=config.bot_token,
        in_memory=True,
        workers=4,
        max_concurrent_transmissions=2,
    )


async def main() -> None:
    """Concurrent entrypoint running the health-check server and Pyrogram client."""
    config = load_config()
    uploader = GoogleDriveUploader(
        service_account_info=config.service_account_info,
        folder_id=config.gdrive_folder_id,
        chunk_size_bytes=config.upload_chunk_size_bytes,
        share_anyone_with_link=config.share_anyone_with_link,
    )

    app = build_pyrogram_client(config)
    media_filter = (filters.document | filters.video | filters.audio) & filters.private

    @app.on_message(filters.command(["start", "help"]) & filters.private)
    async def start_handler(_client: Client, message: Message) -> None:
        user_id = message.from_user.id if message.from_user else 0
        if config.authorized_user_ids and user_id not in config.authorized_user_ids:
            await message.reply_text(
                f"Access denied. Your Telegram User ID (`{user_id}`) is not in `AUTHORIZED_USER_IDS`."
            )
            return

        await message.reply_text(
            "**TeleDrive MTProto Bridge Active**\n\n"
            "Forward or send any **Document, Video, or Audio** file (up to 2GB) in this private chat.\n"
            f"• **Upload Chunk Size:** `{config.upload_chunk_size_mb} MB` (Resumable)\n"
            f"• **Destination Folder:** `{config.gdrive_folder_id or 'Service Account Root'}`\n"
            "• **Disk Safety:** Automatic `finally:` cleanup after every transfer."
        )

    @app.on_message(media_filter)
    async def handle_media_transfer(client: Client, message: Message) -> None:
        user_id = message.from_user.id if message.from_user else 0
        if config.authorized_user_ids and user_id not in config.authorized_user_ids:
            logger.warning("Unauthorized transfer attempt from user_id=%s", user_id)
            await message.reply_text(
                f"Unauthorized user (`{user_id}`). Add your ID to `AUTHORIZED_USER_IDS`."
            )
            return

        filename, expected_size = extract_media_metadata(message)
        unique_prefix = f"{message.chat.id}_{message.id}_{int(time.time())}"
        local_file_path = os.path.join(config.download_dir, f"{unique_prefix}_{filename}")
        downloaded_path: Optional[str] = None

        status_msg = await message.reply_text(
            f"**Initializing MTProto Transfer**\n\n"
            f"**File:** `{filename}`\n"
            f"**Size:** `{format_bytes(expected_size)}`\n"
            f"**Stage:** Preparing download stream...",
            quote=True,
        )

        try:
            # Stage 1: Stream download from Telegram MTProto to temporary file
            dl_tracker = ThrottledProgressTracker(
                status_message=status_msg,
                filename=filename,
                stage_title="1/2 · Downloading from Telegram (MTProto)",
                min_interval_sec=config.progress_update_interval_sec,
            )

            async def tg_progress(current: int, total: int) -> None:
                await dl_tracker.update(current, total or expected_size)

            downloaded_path = await client.download_media(
                message=message,
                file_name=local_file_path,
                progress=tg_progress,
            )

            if not downloaded_path or not os.path.isfile(downloaded_path):
                raise RuntimeError("Download completed without producing a valid local file.")

            actual_size = os.path.getsize(downloaded_path)
            logger.info("Downloaded '%s' (%d bytes) to %s", filename, actual_size, downloaded_path)

            # Stage 2: Chunked Resumable Upload to Google Drive
            ul_tracker = ThrottledProgressTracker(
                status_message=status_msg,
                filename=filename,
                stage_title=f"2/2 · Uploading to Google Drive ({config.upload_chunk_size_mb}MB Chunks)",
                min_interval_sec=config.progress_update_interval_sec,
            )

            uploaded_file = await uploader.upload_file(
                file_path=downloaded_path,
                filename=filename,
                progress_callback=ul_tracker.update,
            )

            await status_msg.edit_text(
                "**Upload Complete — Saved to Google Drive**\n\n"
                f"**Filename:** `{uploaded_file.name}`\n"
                f"**Size:** `{format_bytes(uploaded_file.size_bytes)}`\n"
                f"**Access Mode:** `{uploaded_file.permission_mode}`\n"
                f"**Local Cleanup:** `Verified (Temp file deleted)`\n\n"
                f"**Google Drive Link:** [Open in Google Drive]({uploaded_file.web_view_link})",
                disable_web_page_preview=False,
            )

        except Exception as exc:
            logger.exception("Transfer failed for '%s': %s", filename, exc)
            try:
                await status_msg.edit_text(
                    f"**Transfer Failed**\n\n"
                    f"**File:** `{filename}`\n"
                    f"**Reason:** `{type(exc).__name__}: {exc}`\n"
                    f"**Disk Hygiene:** Local temporary file has been purged."
                )
            except Exception:
                pass
        finally:
            # Crucial Memory & Storage Safety: Always delete temporary file(s)
            for candidate_path in {local_file_path, downloaded_path}:
                if candidate_path and os.path.exists(candidate_path):
                    try:
                        os.remove(candidate_path)
                        logger.info("Deleted temporary file: %s", candidate_path)
                    except OSError as remove_err:
                        logger.error(
                            "Failed to delete temporary file %s: %s",
                            candidate_path,
                            remove_err,
                        )

    # Start aiohttp health server and Pyrogram client concurrently on the same event loop
    health_runner = await start_health_server(config)
    try:
        await app.start()
        me = await app.get_me()
        logger.info(
            "Pyrogram client started as @%s (ID: %s). Listening for private media...",
            getattr(me, "username", None) or "user",
            me.id,
        )
        await idle()
    finally:
        logger.info("Shutting down Pyrogram client and health-check server...")
        try:
            await app.stop()
        except Exception:
            pass
        await health_runner.cleanup()


if __name__ == "__main__":
    asyncio.run(main())
