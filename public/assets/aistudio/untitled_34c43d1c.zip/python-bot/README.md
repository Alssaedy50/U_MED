# TeleDrive MTProto — Personal Telegram-to-Google-Drive Bot

A cloud-native Python MTProto bot built with **Pyrogram (v2.x)**, **TgCrypto**, **Google Drive API v3**, and **aiohttp**. Transfers documents, videos, and audio files up to **2GB** directly from Telegram to Google Drive using chunked resumable uploads (`10MB` / `20MB` chunks) while maintaining strict disk safety (`try...finally` deletion) and a `200 OK` health-check endpoint on port `7860` for 24/7 hosting on **Hugging Face Spaces** or any Docker runtime.

---

## Architecture Highlights

1. **Native MTProto (Bypasses 20MB Bot API Limit)**: Uses `pyrogram` and `tgcrypto` to stream files up to 2GB (or 4GB with a UserBot `SESSION_STRING`).
2. **Chunked Resumable Google Drive Uploads**: Uses `MediaFileUpload(..., resumable=True)` wrapped in `asyncio.to_thread` so multi-gigabyte uploads never block the event loop or spike container RAM.
3. **Guaranteed Disk Cleanup (`finally: os.remove`)**: Every downloaded file is immediately deleted inside a `finally:` block regardless of upload outcome, preventing ephemeral container disk saturation.
4. **Flood-Wait Protected Progress Updates**: Throttles Telegram status edits to once every `4.5` seconds with automatic `FloodWait` backoff.
5. **Hugging Face Spaces Ready**: Runs as non-root `UID 1000` and exposes an `aiohttp` health endpoint at `http://0.0.0.0:7860/health`.

---

## Step 1: Prepare Google Service Account & Base64 Secret

1. Open the [Google Cloud Console](https://console.cloud.google.com/), create or select a project, and enable the **Google Drive API**.
2. Go to **IAM & Admin → Service Accounts**, create a Service Account, and generate a **JSON Key** (`service_account.json`).
3. **Share Your Target Google Drive Folder**:
   - Create a folder in your personal Google Drive.
   - Share that folder with the Service Account's `client_email` (e.g., `teledrive-bot@your-project.iam.gserviceaccount.com`) with **Editor** permissions.
   - Copy the Folder ID from the URL (`https://drive.google.com/drive/folders/<GDRIVE_FOLDER_ID>`).
4. **Base64-Encode the JSON Key** (so you never commit raw JSON files to Git):
   ```bash
   # Linux / macOS
   base64 -w 0 service_account.json
   # macOS (BSD base64)
   base64 -i service_account.json | tr -d '\n'
   ```

---

## Step 2: Configure Environment Secrets

In **Hugging Face Spaces** (*Settings → Variables and secrets → New secret*) or GitHub / Docker, configure the following secrets:

| Secret Name | Required | Description |
| :--- | :--- | :--- |
| `API_ID` | **Yes** | Integer API ID from [my.telegram.org](https://my.telegram.org) |
| `API_HASH` | **Yes** | 32-character API Hash from [my.telegram.org](https://my.telegram.org) |
| `BOT_TOKEN` | **Yes*** | Bot token from `@BotFather` (*or provide `SESSION_STRING` instead*) |
| `SESSION_STRING` | Optional | Pyrogram MTProto UserBot session string (alternative to `BOT_TOKEN`) |
| `GDRIVE_CREDENTIALS_B64` | **Yes** | Single-line Base64-encoded string of your `service_account.json` |
| `GDRIVE_FOLDER_ID` | Recommended | Target Google Drive Folder ID shared with the Service Account |
| `AUTHORIZED_USER_IDS` | Recommended | Comma-separated Telegram User IDs allowed to use the bot (e.g. `123456789,987654321`) |
| `UPLOAD_CHUNK_SIZE_MB` | Optional | Chunk size in MB for resumable uploads (`10` or `20`, default `20`) |

---

## Step 3: Deploy to Hugging Face Spaces (24/7 Free Container)

1. Create a new Space on [Hugging Face](https://huggingface.co/new-space) and select **Docker** as the Space SDK (choose the **Blank** template).
2. Add the secrets listed above in **Settings → Variables and secrets**.
3. Push this repository (`Dockerfile`, `requirements.txt`, `config.py`, `gdrive.py`, `main.py`, `.gitignore`, `README.md`) to your Space or connect your private GitHub repository via GitHub Actions.
4. Once built, Hugging Face Spaces will probe `GET :7860/` and mark your container as **Running**. Forward any document, video, or audio file to your bot in a private chat to archive it directly to Google Drive.
