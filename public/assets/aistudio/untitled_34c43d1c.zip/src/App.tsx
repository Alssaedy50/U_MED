/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  Check,
  Copy,
  Download,
  FileCode2,
  FolderArchive,
  RotateCcw,
  Search,
} from 'lucide-react';
import {
  BotGeneratorConfig,
  generateProjectDeliverables,
} from './utils/botTemplates';
import { createZipBlob, triggerBlobDownload } from './utils/zipBuilder';
import { ServiceAccountEncoder } from './components/ServiceAccountEncoder';
import { TransferSimulator } from './components/TransferSimulator';

const DEFAULT_CONFIG: BotGeneratorConfig = {
  authMode: 'bot_token',
  chunkSizeMb: 20,
  progressIntervalSec: 4.5,
  port: 7860,
  defaultFolderId: '1A2B3C4D5E6F7G8H9I0J_drive_folder',
  authorizedUserIds: '123456789,987654321',
  sharePublicLink: true,
  nonRootUid: 1000,
  base64CredentialsPreview: '',
};

export default function App() {
  const [config, setConfig] = useState<BotGeneratorConfig>(DEFAULT_CONFIG);
  const [activeFileId, setActiveFileId] = useState<string>('main.py');
  const [codeSearch, setCodeSearch] = useState<string>('');
  const [copiedFileId, setCopiedFileId] = useState<string | null>(null);
  const [exportedZipToast, setExportedZipToast] = useState<boolean>(false);
  const [detectedServiceEmail, setDetectedServiceEmail] = useState<string>('');

  const deliverables = useMemo(
    () => generateProjectDeliverables(config),
    [config]
  );

  const activeDeliverable = useMemo(
    () =>
      deliverables.find((d) => d.id === activeFileId) || deliverables[0],
    [deliverables, activeFileId]
  );

  const codeLines = useMemo(
    () => activeDeliverable.content.split('\n'),
    [activeDeliverable]
  );

  const matchingLineIndices = useMemo(() => {
    const query = codeSearch.trim().toLowerCase();
    if (!query) return new Set<number>();
    const matches = new Set<number>();
    codeLines.forEach((line, idx) => {
      if (line.toLowerCase().includes(query)) {
        matches.add(idx);
      }
    });
    return matches;
  }, [codeLines, codeSearch]);

  const handleCopyCode = async (fileId: string, content: string) => {
    await navigator.clipboard.writeText(content);
    setCopiedFileId(fileId);
    setTimeout(() => setCopiedFileId(null), 1800);
  };

  const handleDownloadSingleFile = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    triggerBlobDownload(blob, filename);
  };

  const handleExportProjectZip = () => {
    const zipEntries = deliverables.map((item) => ({
      filename: item.filename,
      content: item.content,
    }));
    const zipBlob = createZipBlob(zipEntries);
    triggerBlobDownload(zipBlob, 'teledrive-mtproto-bot.zip');
    setExportedZipToast(true);
    setTimeout(() => setExportedZipToast(false), 2500);
  };

  const handleResetConfig = () => {
    setConfig((prev) => ({
      ...DEFAULT_CONFIG,
      base64CredentialsPreview: prev.base64CredentialsPreview,
    }));
  };

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100 flex flex-col">
      {/* 3-Zone Top Bar Contract: [Brand title] — [4 nav links] — [1 primary action] */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-8 px-6 py-3.5 bg-[#0B0F17]/95 backdrop-blur border-b border-slate-800">
        <a
          href="#workbench"
          className="text-base font-bold tracking-tight text-slate-50 font-display whitespace-nowrap shrink-0"
        >
          TeleDrive MTProto
        </a>

        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-400">
          <a
            href="#workbench"
            className="hover:text-slate-100 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Code Workbench
          </a>
          <a
            href="#credentials"
            className="hover:text-slate-100 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Base64 Studio
          </a>
          <a
            href="#simulator"
            className="hover:text-slate-100 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Transfer Simulator
          </a>
          <a
            href="#deployment"
            className="hover:text-slate-100 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
          >
            Deployment Guide
          </a>
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={handleExportProjectZip}
            className="px-4 py-2 text-xs font-semibold bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-md transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FolderArchive className="w-3.5 h-3.5" />
            <span>
              {exportedZipToast ? 'Exported ZIP Bundle' : 'Export Project ZIP'}
            </span>
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-[1440px] w-full mx-auto px-6 py-8 space-y-10">
        {/* Hero / Architecture Summary Banner */}
        <section className="border-b border-slate-800/80 pb-7 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div className="space-y-2.5 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 font-mono tabular-nums">
              <span>Python 3.10-slim</span>
              <span aria-hidden="true">·</span>
              <span>Pyrogram 2.0.106 + TgCrypto</span>
              <span aria-hidden="true">·</span>
              <span>Google Drive API v3 Resumable</span>
              <span aria-hidden="true">·</span>
              <span>Port {config.port} Health Server</span>
              <span aria-hidden="true">·</span>
              <span>UID {config.nonRootUid}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-50 font-display text-balance">
              Personal Telegram-to-Google-Drive MTProto Bot Architecture
            </h1>
            <p className="text-sm text-slate-400 leading-relaxed max-w-2xl">
              Bypasses the 20MB HTTP Bot API limit using native MTProto streaming up to 2GB,
              executes non-blocking {config.chunkSizeMb}MB chunked resumable uploads to Google Drive,
              and enforces ephemeral disk safety via <code className="text-slate-200">finally: os.remove()</code>.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 border border-slate-800 bg-slate-900/50 rounded-lg p-4 shrink-0">
            <div>
              <div className="text-xs text-slate-400">Max Payload</div>
              <div className="text-base font-semibold text-slate-100 font-mono tabular-nums mt-0.5">
                2.00 GB
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400">Resumable Chunk</div>
              <div className="text-base font-semibold text-sky-400 font-mono tabular-nums mt-0.5">
                {config.chunkSizeMb} MB
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400">Flood Throttle</div>
              <div className="text-base font-semibold text-slate-100 font-mono tabular-nums mt-0.5">
                {config.progressIntervalSec.toFixed(1)}s
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400">Health Probe</div>
              <div className="text-base font-semibold text-emerald-400 font-mono tabular-nums mt-0.5">
                :{config.port} OK
              </div>
            </div>
          </div>
        </section>

        {/* Primary Split Workbench: Configurator (Left) + Deliverable Inspector (Right) */}
        <section
          id="workbench"
          className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start"
        >
          {/* Left Column: Interactive Runtime Configurator */}
          <div className="lg:col-span-4 border border-slate-800 bg-slate-900/60 rounded-lg p-5 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-100">
                  Runtime Configuration
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Updates generated Python code &amp; Docker config live
                </p>
              </div>
              <button
                type="button"
                onClick={handleResetConfig}
                title="Reset configuration to recommended defaults"
                className="px-2.5 py-1 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800/80 hover:bg-slate-800 rounded transition-colors flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            </div>

            {/* 1. Telegram MTProto Auth Mode */}
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-slate-300">
                1. MTProto Authentication Mode
              </label>
              <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 border border-slate-800 rounded-md">
                <button
                  type="button"
                  onClick={() =>
                    setConfig((c) => ({ ...c, authMode: 'bot_token' }))
                  }
                  className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    config.authMode === 'bot_token'
                      ? 'bg-sky-500 text-slate-950 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Bot Token (Default)
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setConfig((c) => ({ ...c, authMode: 'session_string' }))
                  }
                  className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    config.authMode === 'session_string'
                      ? 'bg-sky-500 text-slate-950 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  UserBot Session
                </button>
              </div>
              <p className="text-xs text-slate-500">
                Both modes remain supported via env vars (<code className="text-slate-400">BOT_TOKEN</code> or{' '}
                <code className="text-slate-400">SESSION_STRING</code>) in <code className="text-slate-400">config.py</code>.
              </p>
            </div>

            {/* 2. Google Drive Resumable Chunk Size */}
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-slate-300">
                2. Google Drive Resumable Chunk Size
              </label>
              <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 border border-slate-800 rounded-md">
                {([10, 20] as const).map((mb) => (
                  <button
                    key={mb}
                    type="button"
                    onClick={() => setConfig((c) => ({ ...c, chunkSizeMb: mb }))}
                    className={`px-3 py-1.5 text-xs font-mono tabular-nums font-medium rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                      config.chunkSizeMb === mb
                        ? 'bg-sky-500 text-slate-950 font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mb} MB ({mb * 1024} KB)
                  </button>
                ))}
              </div>
              <p className="text-xs text-slate-500">
                Passed to <code className="text-slate-400">MediaFileUpload(resumable=True)</code> to prevent RAM spikes on 1GB+ transfers.
              </p>
            </div>

            {/* 3. Flood-Wait Edit Throttle Interval */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <label className="font-medium text-slate-300">
                  3. Progress Update Throttle (Flood-Wait Guard)
                </label>
                <span className="font-mono tabular-nums text-sky-400">
                  {config.progressIntervalSec.toFixed(1)}s
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950 border border-slate-800 rounded-md">
                {[4.0, 4.5, 5.0].map((sec) => (
                  <button
                    key={sec}
                    type="button"
                    onClick={() =>
                      setConfig((c) => ({ ...c, progressIntervalSec: sec }))
                    }
                    className={`px-2.5 py-1.5 text-xs font-mono tabular-nums rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                      config.progressIntervalSec === sec
                        ? 'bg-slate-800 text-slate-100 font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {sec.toFixed(1)}s
                  </button>
                ))}
              </div>
            </div>

            {/* 4. Authorized Telegram User IDs */}
            <div className="space-y-1.5">
              <label
                htmlFor="auth-users-input"
                className="block text-xs font-medium text-slate-300"
              >
                4. Authorized Telegram User IDs (<code className="text-slate-400">AUTHORIZED_USER_IDS</code>)
              </label>
              <input
                id="auth-users-input"
                type="text"
                value={config.authorizedUserIds}
                onChange={(e) =>
                  setConfig((c) => ({ ...c, authorizedUserIds: e.target.value }))
                }
                placeholder="e.g. 123456789,987654321"
                className="w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-xs font-mono tabular-nums text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-sky-500"
              />
              <p className="text-xs text-slate-500">
                Restricts private media transfers strictly to your personal Telegram IDs.
              </p>
            </div>

            {/* 5. Default Google Drive Folder ID */}
            <div className="space-y-1.5">
              <label
                htmlFor="folder-id-input"
                className="block text-xs font-medium text-slate-300"
              >
                5. Target Google Drive Folder ID (<code className="text-slate-400">GDRIVE_FOLDER_ID</code>)
              </label>
              <input
                id="folder-id-input"
                type="text"
                value={config.defaultFolderId}
                onChange={(e) =>
                  setConfig((c) => ({ ...c, defaultFolderId: e.target.value }))
                }
                placeholder="Leave blank for Service Account root Drive"
                className="w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-xs font-mono text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-sky-500"
              />
              {detectedServiceEmail && (
                <p className="text-xs text-emerald-400 font-mono truncate">
                  Share folder with: {detectedServiceEmail}
                </p>
              )}
            </div>

            {/* 6. Link Sharing Permission */}
            <div className="pt-1 border-t border-slate-800/80 flex items-center justify-between gap-3">
              <div>
                <div className="text-xs font-medium text-slate-300">
                  Configure Public Reader Link
                </div>
                <div className="text-xs text-slate-500">
                  Sets <code className="text-slate-400">role=&quot;reader&quot;, type=&quot;anyone&quot;</code> on uploaded files
                </div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={config.sharePublicLink}
                onClick={() =>
                  setConfig((c) => ({
                    ...c,
                    sharePublicLink: !c.sharePublicLink,
                  }))
                }
                className={`px-3 py-1.5 text-xs font-mono rounded-md border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  config.sharePublicLink
                    ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                {config.sharePublicLink ? 'Enabled' : 'Folder Inherited'}
              </button>
            </div>
          </div>

          {/* Right Column: Multi-File Deliverable Code Inspector */}
          <div className="lg:col-span-8 border border-slate-800 bg-slate-900/60 rounded-lg overflow-hidden flex flex-col">
            {/* File Selector Bar */}
            <div className="flex items-center gap-1 p-2 bg-slate-950 border-b border-slate-800 overflow-x-auto">
              {deliverables.map((item) => {
                const isActive = item.id === activeDeliverable.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveFileId(item.id)}
                    className={`px-3 py-1.5 text-xs font-mono rounded-md transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                      isActive
                        ? 'bg-sky-500 text-slate-950 font-semibold'
                        : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900'
                    }`}
                  >
                    <FileCode2 className="w-3.5 h-3.5" />
                    <span>{item.filename}</span>
                  </button>
                );
              })}
            </div>

            {/* Active Deliverable Header & Action Controls */}
            <div className="p-4 border-b border-slate-800 bg-slate-900/90 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2 text-xs text-slate-400 font-mono tabular-nums">
                    <span className="text-slate-100 font-semibold">
                      {activeDeliverable.filename}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{activeDeliverable.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{codeLines.length} lines</span>
                    <span aria-hidden="true">·</span>
                    <span>{activeDeliverable.content.length} bytes</span>
                  </div>
                  <p className="text-xs text-slate-300">
                    {activeDeliverable.summary}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={codeSearch}
                      onChange={(e) => setCodeSearch(e.target.value)}
                      placeholder="Filter lines..."
                      className="pl-8 pr-2.5 py-1.5 text-xs font-mono bg-slate-950 border border-slate-800 rounded-md text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-sky-500 w-36 sm:w-44"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      handleCopyCode(
                        activeDeliverable.id,
                        activeDeliverable.content
                      )
                    }
                    className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
                  >
                    {copiedFileId === activeDeliverable.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy File</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      handleDownloadSingleFile(
                        activeDeliverable.filename,
                        activeDeliverable.content
                      )
                    }
                    className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              </div>

              {/* Unboxed specification highlights with typographic separators */}
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400 pt-1">
                {activeDeliverable.highlights.map((item, index) => (
                  <React.Fragment key={index}>
                    {index > 0 && <span aria-hidden="true">·</span>}
                    <span className="font-mono text-slate-300">{item}</span>
                  </React.Fragment>
                ))}
              </div>
            </div>

            {/* Code Viewport with Line Numbers */}
            <div className="bg-[#070A10] overflow-x-auto max-h-[560px] overflow-y-auto font-mono text-xs leading-relaxed">
              <table className="w-full border-collapse">
                <tbody>
                  {codeLines.map((line, index) => {
                    const isMatch = matchingLineIndices.has(index);
                    return (
                      <tr
                        key={index}
                        className={
                          isMatch
                            ? 'bg-sky-500/15 text-sky-100'
                            : 'hover:bg-slate-900/60'
                        }
                      >
                        <td className="select-none text-right pr-4 pl-4 py-0.5 text-slate-600 tabular-nums border-r border-slate-900 w-12 align-top">
                          {index + 1}
                        </td>
                        <td className="pl-4 pr-6 py-0.5 text-slate-200 whitespace-pre">
                          {line || ' '}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* Base64 Google Service Account Credential Encoder */}
        <section id="credentials" className="scroll-mt-20">
          <ServiceAccountEncoder
            onEncodedChange={(b64, clientEmail) => {
              setConfig((c) => ({ ...c, base64CredentialsPreview: b64 }));
              if (clientEmail) setDetectedServiceEmail(clientEmail);
            }}
          />
        </section>

        {/* Interactive MTProto Transfer & Cleanup Simulator */}
        <section id="simulator" className="scroll-mt-20">
          <TransferSimulator
            chunkSizeMb={config.chunkSizeMb}
            progressIntervalSec={config.progressIntervalSec}
            folderId={config.defaultFolderId}
          />
        </section>

        {/* Deployment Checklist for Hugging Face Spaces & Docker */}
        <section
          id="deployment"
          className="scroll-mt-20 border border-slate-800 bg-slate-900/60 rounded-lg p-6 space-y-5"
        >
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-base font-semibold text-slate-100 font-display">
                24/7 Container Deployment Checklist (Hugging Face Spaces &amp; Docker)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                All 6 deliverables are pre-configured for non-root UID {config.nonRootUid} and health-check port {config.port}.
              </p>
            </div>
            <button
              type="button"
              onClick={handleExportProjectZip}
              className="px-4 py-2 text-xs font-semibold bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              Download Complete Repository (.zip)
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="text-xs font-mono text-sky-400 tabular-nums">
                01. Telegram MTProto Setup
              </div>
              <h3 className="text-sm font-semibold text-slate-100">
                Obtain API_ID &amp; API_HASH
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Log in to <code className="text-slate-200">my.telegram.org</code>, open{' '}
                <strong>API development tools</strong>, and copy your integer{' '}
                <code className="text-slate-200">API_ID</code> and 32-character{' '}
                <code className="text-slate-200">API_HASH</code>. Pair with either a{' '}
                <code className="text-slate-200">BOT_TOKEN</code> from @BotFather or a Pyrogram{' '}
                <code className="text-slate-200">SESSION_STRING</code>.
              </p>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-mono text-sky-400 tabular-nums">
                02. Google Drive Folder Access
              </div>
              <h3 className="text-sm font-semibold text-slate-100">
                Share Folder with Service Account
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Create a target folder in Google Drive, share it with your Service Account&apos;s{' '}
                <code className="text-slate-200">client_email</code> as <strong>Editor</strong>, and set the
                folder URL ID as <code className="text-slate-200">GDRIVE_FOLDER_ID</code>. Encode the JSON key into{' '}
                <code className="text-slate-200">GDRIVE_CREDENTIALS_B64</code> above.
              </p>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-mono text-sky-400 tabular-nums">
                03. Hugging Face Spaces Container
              </div>
              <h3 className="text-sm font-semibold text-slate-100">
                Deploy Blank Docker Space
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Create a new Space using the <strong>Docker (Blank)</strong> SDK, add your secrets under{' '}
                <em>Settings → Variables and secrets</em>, and push the exported files. The{' '}
                <code className="text-slate-200">aiohttp</code> server responds on port{' '}
                <code className="text-slate-200">{config.port}</code> to keep the container healthy 24/7.
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-800/80 py-5 px-6 text-xs text-slate-500">
        <div className="max-w-[1440px] mx-auto flex flex-wrap items-center justify-between gap-4">
          <span>
            TeleDrive MTProto Project Generator · Python files also written to /python-bot/ in workspace
          </span>
          <div className="flex items-center gap-4 font-mono tabular-nums">
            <span>Pyrogram 2.0.106</span>
            <span aria-hidden="true">·</span>
            <span>Drive API v3</span>
            <span aria-hidden="true">·</span>
            <span>Port {config.port}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
