/**
 * Pure TypeScript PKZIP builder for packaging all Python bot deliverables
 * into a downloadable .zip archive directly in the browser.
 */

export interface ZipEntryInput {
  filename: string;
  content: string;
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ bytes[i]) & 0xff];
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function writeUint16LE(buf: Uint8Array, offset: number, val: number): void {
  buf[offset] = val & 0xff;
  buf[offset + 1] = (val >>> 8) & 0xff;
}

function writeUint32LE(buf: Uint8Array, offset: number, val: number): void {
  buf[offset] = val & 0xff;
  buf[offset + 1] = (val >>> 8) & 0xff;
  buf[offset + 2] = (val >>> 16) & 0xff;
  buf[offset + 3] = (val >>> 24) & 0xff;
}

export function createZipBlob(files: ZipEntryInput[]): Blob {
  const encoder = new TextEncoder();
  const localChunks: Uint8Array[] = [];
  const centralChunks: Uint8Array[] = [];
  let currentOffset = 0;

  for (const file of files) {
    const nameBytes = encoder.encode(file.filename);
    const dataBytes = encoder.encode(file.content);
    const fileCrc = crc32(dataBytes);
    const size = dataBytes.length;

    // Local file header (30 bytes + filename)
    const localHeader = new Uint8Array(30 + nameBytes.length);
    writeUint32LE(localHeader, 0, 0x04034b50); // Local file header signature
    writeUint16LE(localHeader, 4, 20); // Version needed to extract (2.0)
    writeUint16LE(localHeader, 6, 0x0800); // General purpose bit flag (UTF-8)
    writeUint16LE(localHeader, 8, 0); // Compression method (0 = store)
    writeUint16LE(localHeader, 10, 0x4800); // Last mod file time
    writeUint16LE(localHeader, 12, 0x555b); // Last mod file date
    writeUint32LE(localHeader, 14, fileCrc); // CRC-32
    writeUint32LE(localHeader, 18, size); // Compressed size
    writeUint32LE(localHeader, 22, size); // Uncompressed size
    writeUint16LE(localHeader, 26, nameBytes.length); // File name length
    writeUint16LE(localHeader, 28, 0); // Extra field length
    localHeader.set(nameBytes, 30);

    localChunks.push(localHeader, dataBytes);

    // Central directory header (46 bytes + filename)
    const centralHeader = new Uint8Array(46 + nameBytes.length);
    writeUint32LE(centralHeader, 0, 0x02014b50); // Central file header signature
    writeUint16LE(centralHeader, 4, 20); // Version made by
    writeUint16LE(centralHeader, 6, 20); // Version needed to extract
    writeUint16LE(centralHeader, 8, 0x0800); // General purpose bit flag (UTF-8)
    writeUint16LE(centralHeader, 10, 0); // Compression method (0 = store)
    writeUint16LE(centralHeader, 12, 0x4800); // Last mod file time
    writeUint16LE(centralHeader, 14, 0x555b); // Last mod file date
    writeUint32LE(centralHeader, 16, fileCrc); // CRC-32
    writeUint32LE(centralHeader, 20, size); // Compressed size
    writeUint32LE(centralHeader, 24, size); // Uncompressed size
    writeUint16LE(centralHeader, 28, nameBytes.length); // File name length
    writeUint16LE(centralHeader, 30, 0); // Extra field length
    writeUint16LE(centralHeader, 32, 0); // File comment length
    writeUint16LE(centralHeader, 34, 0); // Disk number start
    writeUint16LE(centralHeader, 36, 0); // Internal file attributes
    writeUint32LE(centralHeader, 38, 0); // External file attributes
    writeUint32LE(centralHeader, 42, currentOffset); // Relative offset of local header
    centralHeader.set(nameBytes, 46);

    centralChunks.push(centralHeader);
    currentOffset += localHeader.length + dataBytes.length;
  }

  let centralSize = 0;
  for (const chunk of centralChunks) {
    centralSize += chunk.length;
  }

  // End of central directory record (22 bytes)
  const eocd = new Uint8Array(22);
  writeUint32LE(eocd, 0, 0x06054b50); // End of central dir signature
  writeUint16LE(eocd, 4, 0); // Number of this disk
  writeUint16LE(eocd, 6, 0); // Disk where central directory starts
  writeUint16LE(eocd, 8, files.length); // Number of central directory records on this disk
  writeUint16LE(eocd, 10, files.length); // Total number of central directory records
  writeUint32LE(eocd, 12, centralSize); // Size of central directory
  writeUint32LE(eocd, 16, currentOffset); // Offset of start of central directory
  writeUint16LE(eocd, 20, 0); // Comment length

  return new Blob([...localChunks, ...centralChunks, eocd], {
    type: 'application/zip',
  });
}

export function triggerBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
