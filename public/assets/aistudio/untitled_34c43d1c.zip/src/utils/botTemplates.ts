export interface BotGeneratorConfig {
  authMode: 'bot_token' | 'session_string' | 'dual';
  chunkSizeMb: 10 | 20;
  progressIntervalSec: number;
  port: number;
  defaultFolderId: string;
  authorizedUserIds: string;
  sharePublicLink: boolean;
  nonRootUid: number;
  base64CredentialsPreview: string;
}

export interface ProjectDeliverable {
  id: string;
  filename: string;
  category: 'Core Python' | 'Container & Deps' | 'Docs & Git';
  language: 'python' | 'dockerfile' | 'text' | 'markdown';
  summary: string;
  highlights: string[];
  content: string;
}

export function generateProjectDeliverables(
  cfg: BotGeneratorConfig
): ProjectDeliverable[] {
  const requirementsTxt = `# Telegram MTProto Client & Fast Cryptography
pyrogram==2.0.106
tgcrypto==1.2.5

# Official Google Drive API v3 & Authentication Libraries
google-api-python-client==2.149.0
google-auth==2.35.0
google-auth-httplib2==0.2.0
google-auth-oauthlib==1.2.1

# Asynchronous Web Server for Container Health Check (Port ${cfg.port})
aiohttp==3.10.10
`;

  const configPy = `"""
Centralized configuration module for the Telegram-to-Google-Drive MTProto Bot.
Reads all settings strictly from environment variables to ensure zero secrets
are ever hardcoded or committed to version control.
"""

import base64
import json
import logging
import os
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, Set

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger("teledrive.config")


def _parse_authorized_users(raw_value: str) -> Set[int]:
    """Parse a comma-separated list of integer Telegram User IDs."""
    user_ids: Set[int] = set()
    if not raw_value or not raw_value.strip():
        return user_ids
    for token in raw_value.split(","):
        cleaned = token.strip()
        if not cleaned:
            continue
        try:
            user_ids.add(int(cleaned))
        except ValueError as exc:
            raise ValueError(
                f"Invalid Telegram User ID '{cleaned}' in AUTHORIZED_USER_IDS. Must be integer."
            ) from exc
    return user_ids


def _load_service_account_info() -> Dict[str, Any]:
    """
    Decode Google Service Account credentials from GDRIVE_CREDENTIALS_B64
    (Base64-encoded JSON) or fallback to raw SERVICE_ACCOUNT_JSON env var.
    """
    b64_creds = os.environ.get("GDRIVE_CREDENTIALS_B64", "").strip()
    raw_json = os.environ.get("SERVICE_ACCOUNT_JSON", "").strip()

    if b64_creds:
        try:
            decoded_bytes = base64.b64decode(b64_creds)
            creds_dict = json.loads(decoded_bytes.decode("utf-8"))
        except Exception as exc:
            raise ValueError(
                "Failed to decode GDRIVE_CREDENTIALS_B64. Ensure it is valid Base64-encoded JSON."
            ) from exc
    elif raw_json:
        try:
            creds_dict = json.loads(raw_json)
        except Exception as exc:
            raise ValueError(
                "Failed to parse SERVICE_ACCOUNT_JSON. Ensure it contains valid JSON."
            ) from exc
    else:
        raise EnvironmentError(
            "Missing Google Drive credentials. Set GDRIVE_CREDENTIALS_B64 (recommended) "
            "or SERVICE_ACCOUNT_JSON in your environment variables."
        )

    required_keys = {"type", "project_id", "private_key", "client_email"}
    missing = required_keys - set(creds_dict.keys())
    if missing:
        raise ValueError(
            f"Service Account JSON is missing required fields: {', '.join(sorted(missing))}"
        )

    return creds_dict


@dataclass(frozen=True)
class Config:
    """Immutable runtime configuration loaded from environment variables."""

    # Telegram MTProto Credentials
    api_id: int
    api_hash: str
    bot_token: Optional[str] = None
    session_string: Optional[str] = None

    # Access Control (Restricted to authorized user IDs via env var)
    authorized_user_ids: Set[int] = field(default_factory=set)

    # Google Drive Settings
    gdrive_folder_id: Optional[str] = None
    service_account_info: Dict[str, Any] = field(default_factory=dict)
    share_anyone_with_link: bool = ${cfg.sharePublicLink ? 'True' : 'False'}

    # Transfer & Memory Safety Settings
    upload_chunk_size_mb: int = ${cfg.chunkSizeMb}
    progress_update_interval_sec: float = ${cfg.progressIntervalSec.toFixed(1)}
    download_dir: str = "/tmp/teledrive_downloads"

    # Container Health Check Server
    port: int = ${cfg.port}
    host: str = "0.0.0.0"

    @property
    def upload_chunk_size_bytes(self) -> int:
        """Return resumable upload chunk size in bytes (must be multiple of 256 KB)."""
        return self.upload_chunk_size_mb * 1024 * 1024


def load_config() -> Config:
    """Validate and load all configuration parameters from environment variables."""
    api_id_raw = os.environ.get("API_ID", "").strip()
    if not api_id_raw:
        raise EnvironmentError("Missing required environment variable: API_ID")
    try:
        api_id = int(api_id_raw)
    except ValueError as exc:
        raise ValueError("API_ID must be a valid integer from my.telegram.org") from exc

    api_hash = os.environ.get("API_HASH", "").strip()
    if not api_hash:
        raise EnvironmentError("Missing required environment variable: API_HASH")

    bot_token = os.environ.get("BOT_TOKEN", "").strip() or None
    session_string = os.environ.get("SESSION_STRING", "").strip() or None

    if not bot_token and not session_string:
        raise EnvironmentError(
            "Authentication required: Provide either BOT_TOKEN (for automated bot) "
            "or SESSION_STRING (for MTProto UserBot) in environment variables."
        )

    authorized_users = _parse_authorized_users(
        os.environ.get("AUTHORIZED_USER_IDS", "${cfg.authorizedUserIds}")
    )
    if not authorized_users:
        logger.warning(
            "AUTHORIZED_USER_IDS is empty. For security, set a comma-separated list "
            "of Telegram User IDs allowed to transfer files."
        )

    gdrive_folder_id = (
        os.environ.get("GDRIVE_FOLDER_ID", "${cfg.defaultFolderId}").strip() or None
    )
    service_account_info = _load_service_account_info()

    share_anyone = os.environ.get(
        "GDRIVE_PUBLIC_LINK", "${cfg.sharePublicLink ? 'true' : 'false'}"
    ).strip().lower() in {"1", "true", "yes"}

    chunk_mb = int(os.environ.get("UPLOAD_CHUNK_SIZE_MB", "${cfg.chunkSizeMb}").strip())
    if chunk_mb not in {5, 10, 20, 50}:
        chunk_mb = ${cfg.chunkSizeMb}

    progress_interval = float(
        os.environ.get("PROGRESS_UPDATE_INTERVAL", "${cfg.progressIntervalSec.toFixed(1)}").strip()
    )
    if progress_interval < 3.0:
        progress_interval = ${cfg.progressIntervalSec.toFixed(1)}

    port = int(os.environ.get("PORT", "${cfg.port}").strip())
    download_dir = os.environ.get("DOWNLOAD_DIR", "/tmp/teledrive_downloads").strip()
    os.makedirs(download_dir, exist_ok=True)

    return Config(
        api_id=api_id,
        api_hash=api_hash,
        bot_token=bot_token,
        session_string=session_string,
        authorized_user_ids=authorized_users,
        gdrive_folder_id=gdrive_folder_id,
        service_account_info=service_account_info,
        share_anyone_with_link=share_anyone,
        upload_chunk_size_mb=chunk_mb,
        progress_update_interval_sec=progress_interval,
        download_dir=download_dir,
        port=port,
    )
`;

  const gdrivePy = `"""
Modular Google Drive API v3 helper class with chunked resumable uploads.
Streams large files (up to 2GB+) in ${cfg.chunkSizeMb}MB chunks without memory spikes
and runs blocking HTTP calls inside a worker thread to keep asyncio responsive.
"""

import asyncio
import logging
import mimetypes
import os
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Dict, Optional

from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload

logger = logging.getLogger("teledrive.gdrive")

SCOPES = ["https://www.googleapis.com/auth/drive"]

ProgressCallback = Callable[[int, int], Optional[Awaitable[None]]]


@dataclass(frozen=True)
class UploadedDriveFile:
    """Structured metadata returned upon successful Google Drive upload."""

    file_id: str
    name: str
    size_bytes: int
    web_view_link: str
    web_content_link: Optional[str]
    permission_mode: str


class GoogleDriveUploader:
    """Handles authenticated chunked resumable file uploads to Google Drive."""

    def __init__(
        self,
        service_account_info: Dict[str, Any],
        folder_id: Optional[str] = None,
        chunk_size_bytes: int = ${cfg.chunkSizeMb} * 1024 * 1024,
        share_anyone_with_link: bool = ${cfg.sharePublicLink ? 'True' : 'False'},
    ) -> None:
        self.folder_id = folder_id
        self.chunk_size_bytes = chunk_size_bytes
        self.share_anyone_with_link = share_anyone_with_link
        self.client_email = service_account_info.get("client_email", "unknown")

        self._credentials = service_account.Credentials.from_service_account_info(
            service_account_info, scopes=SCOPES
        )
        logger.info(
            "Initialized Google Drive credentials for Service Account: %s",
            self.client_email,
        )

    def _build_service(self):
        """Build a thread-local Google Drive v3 service resource."""
        return build("drive", "v3", credentials=self._credentials, cache_discovery=False)

    async def upload_file(
        self,
        file_path: str,
        filename: str,
        progress_callback: Optional[ProgressCallback] = None,
    ) -> UploadedDriveFile:
        """
        Upload a local file to Google Drive using chunked resumable MediaFileUpload.

        Args:
            file_path: Absolute path to the local temporary file.
            filename: Target filename in Google Drive.
            progress_callback: Optional async or sync callback receiving (uploaded_bytes, total_bytes).

        Returns:
            UploadedDriveFile containing the Drive file ID, size, and webViewLink.
        """
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"Local file not found for upload: {file_path}")

        total_size = os.path.getsize(file_path)
        mime_type, _ = mimetypes.guess_type(filename)
        if not mime_type:
            mime_type = "application/octet-stream"

        file_metadata: Dict[str, Any] = {"name": filename}
        if self.folder_id:
            file_metadata["parents"] = [self.folder_id]

        # Initialize Drive service and resumable media upload request
        service = await asyncio.to_thread(self._build_service)
        media = MediaFileUpload(
            file_path,
            mimetype=mime_type,
            chunksize=self.chunk_size_bytes,
            resumable=True,
        )

        request = service.files().create(
            body=file_metadata,
            media_body=media,
            fields="id, name, size, webViewLink, webContentLink",
            supportsAllDrives=True,
        )

        response: Optional[Dict[str, Any]] = None
        logger.info(
            "Starting resumable upload for '%s' (%d bytes, chunk=%d MB)",
            filename,
            total_size,
            self.chunk_size_bytes // (1024 * 1024),
        )

        while response is None:
            status, response = await asyncio.to_thread(request.next_chunk, num_retries=5)
            if status and progress_callback:
                uploaded_bytes = int(status.resumable_progress)
                maybe_coro = progress_callback(uploaded_bytes, total_size)
                if asyncio.iscoroutine(maybe_coro):
                    await maybe_coro

        # Ensure 100% completion callback is fired
        if progress_callback:
            maybe_coro = progress_callback(total_size, total_size)
            if asyncio.iscoroutine(maybe_coro):
                await maybe_coro

        file_id = response.get("id", "")
        permission_status = "Inherited from Folder"

        if self.share_anyone_with_link and file_id:
            permission_status = await asyncio.to_thread(
                self._apply_public_reader_permission, service, file_id
            )
        elif not self.folder_id and file_id:
            # If uploaded to Service Account's own root Drive without a shared folder ID,
            # apply link-reader permission so the user can actually open the webViewLink.
            permission_status = await asyncio.to_thread(
                self._apply_public_reader_permission, service, file_id
            )

        web_view_link = response.get(
            "webViewLink", f"https://drive.google.com/file/d/{file_id}/view"
        )
        web_content_link = response.get("webContentLink")

        logger.info(
            "Completed Google Drive upload for '%s' -> ID=%s", filename, file_id
        )

        return UploadedDriveFile(
            file_id=file_id,
            name=response.get("name", filename),
            size_bytes=int(response.get("size", total_size)),
            web_view_link=web_view_link,
            web_content_link=web_content_link,
            permission_mode=permission_status,
        )

    @staticmethod
    def _apply_public_reader_permission(service: Any, file_id: str) -> str:
        """Grant 'anyone with link' reader permission and return a human-readable status."""
        try:
            service.permissions().create(
                fileId=file_id,
                body={"type": "anyone", "role": "reader"},
                fields="id",
                supportsAllDrives=True,
            ).execute()
            return "Anyone with link (Reader)"
        except HttpError as exc:
            logger.warning(
                "Could not set public link permission on file %s: %s", file_id, exc
            )
            return "Restricted (Folder / Service Account Access)"
`;

  const mainPy = `"""
Core entrypoint for the Personal Telegram-to-Google-Drive MTProto Bot.
Runs both an aiohttp health-check web server (Port ${cfg.port} for Hugging Face Spaces)
and the Pyrogram MTProto client concurrently within a single asyncio event loop.
"""

import asyncio
import logging
import math
import os
import time
from typing import Optional

from aiohttp import web
from pyrogram import Client, filters, idle
from pyrogram.errors import FloodWait, MessageNotModified
from pyrogram.types import Message

from config import Config, load_config
from gdrive import GoogleDriveUploader

logger = logging.getLogger("teledrive.main")


def format_bytes(size_bytes: float) -> str:
    """Convert raw bytes into a human-readable string (KB, MB, GB)."""
    if size_bytes <= 0:
        return "0 B"
    units = ("B", "KB", "MB", "GB", "TB")
    index = int(math.floor(math.log(size_bytes, 1024)))
    index = min(index, len(units) - 1)
    value = size_bytes / math.pow(1024, index)
    return f"{value:.2f} {units[index]}"


def format_duration(seconds: float) -> str:
    """Format remaining seconds into a concise human-readable ETA."""
    if seconds <= 0 or math.isinf(seconds) or math.isnan(seconds):
        return "0s"
    total_secs = int(round(seconds))
    mins, secs = divmod(total_secs, 60)
    hours, mins = divmod(mins, 60)
    if hours > 0:
        return f"{hours}h {mins}m {secs}s"
    if mins > 0:
        return f"{mins}m {secs}s"
    return f"{secs}s"


def render_progress_bar(percentage: float, length: int = 12) -> str:
    """Render a clean ASCII progress bar for Telegram status messages."""
    clamped = max(0.0, min(100.0, percentage))
    filled = int(round((clamped / 100.0) * length))
    return "█" * filled + "░" * (length - filled)


class ThrottledProgressTracker:
    """
    Throttles Telegram edit_message_text calls to once every ${cfg.progressIntervalSec.toFixed(1)} seconds
    to prevent FloodWait limits while transferring multi-gigabyte files.
    """

    def __init__(
        self,
        status_message: Message,
        filename: str,
        stage_title: str,
        min_interval_sec: float = ${cfg.progressIntervalSec.toFixed(1)},
    ) -> None:
        self.status_message = status_message
        self.filename = filename
        self.stage_title = stage_title
        self.min_interval_sec = min_interval_sec
        self.start_time = time.monotonic()
        self.last_update_time = 0.0

    async def update(self, current_bytes: int, total_bytes: int) -> None:
        """Edit the Telegram status message if the throttle interval has elapsed."""
        now = time.monotonic()
        is_complete = total_bytes > 0 and current_bytes >= total_bytes

        if not is_complete and (now - self.last_update_time) < self.min_interval_sec:
            return

        self.last_update_time = now
        elapsed = max(0.001, now - self.start_time)
        speed_bps = current_bytes / elapsed
        percentage = (current_bytes / total_bytes * 100.0) if total_bytes > 0 else 0.0
        remaining_bytes = max(0, total_bytes - current_bytes)
        eta_seconds = (remaining_bytes / speed_bps) if speed_bps > 0 else 0.0

        bar = render_progress_bar(percentage)
        text = (
            f"**{self.stage_title}**\\n\\n"
            f"**File:** \`{self.filename}\`\\n"
            f"**Progress:** \`{bar}\` \`{percentage:.1f}%\`\\n"
            f"**Transferred:** \`{format_bytes(current_bytes)} / {format_bytes(total_bytes)}\`\\n"
            f"**Speed:** \`{format_bytes(speed_bps)}/s\` · **ETA:** \`{format_duration(eta_seconds)}\`"
        )

        try:
            await self.status_message.edit_text(text, disable_web_page_preview=True)
        except MessageNotModified:
            pass
        except FloodWait as exc:
            logger.warning("Telegram FloodWait encountered: sleeping %d seconds", exc.value)
            await asyncio.sleep(exc.value)
        except Exception as exc:
            logger.debug("Non-fatal progress update error: %s", exc)


def extract_media_metadata(message: Message) -> tuple[str, int]:
    """Extract a safe filename and file size from a document, video, or audio message."""
    media = message.document or message.video or message.audio
    if media is None:
        raise ValueError("Message does not contain a supported media attachment.")

    file_size = getattr(media, "file_size", 0) or 0
    raw_name = getattr(media, "file_name", None)

    if not raw_name:
        ext = ".bin"
        mime = getattr(media, "mime_type", "") or ""
        if "mp4" in mime:
            ext = ".mp4"
        elif "mpeg" in mime or "mp3" in mime:
            ext = ".mp3"
        elif "pdf" in mime:
            ext = ".pdf"
        raw_name = f"telegram_{message.id}_{int(time.time())}{ext}"

    # Sanitize path separators to prevent directory traversal
    safe_name = os.path.basename(raw_name.replace("\\\\", "_").replace("/", "_"))
    return safe_name, file_size


async def start_health_server(config: Config) -> web.AppRunner:
    """Start a lightweight aiohttp web server on port ${cfg.port} returning 200 OK."""
    app = web.Application()

    async def handle_health(_request: web.Request) -> web.Response:
        return web.json_response(
            {
                "status": "OK",
                "service": "teledrive-mtproto-bot",
                "port": config.port,
            },
            status=200,
        )

    app.router.add_get("/", handle_health)
    app.router.add_get("/health", handle_health)
    app.router.add_get("/healthz", handle_health)

    runner = web.AppRunner(app, access_log=None)
    await runner.setup()
    site = web.TCPSite(runner, host=config.host, port=config.port)
    await site.start()
    logger.info("Health-check server listening on http://%s:%d", config.host, config.port)
    return runner


def build_pyrogram_client(config: Config) -> Client:
    """Initialize Pyrogram MTProto client via Bot Token or UserBot Session String."""
    if config.session_string:
        logger.info("Initializing Pyrogram MTProto client using SESSION_STRING (UserBot mode)")
        return Client(
            name="teledrive_userbot",
            api_id=config.api_id,
            api_hash=config.api_hash,
            session_string=config.session_string,
            in_memory=True,
            workers=4,
            max_concurrent_transmissions=2,
        )

    logger.info("Initializing Pyrogram MTProto client using BOT_TOKEN")
    return Client(
        name="teledrive_bot",
        api_id=config.api_id,
        api_hash=config.api_hash,
        bot_token=config.bot_token,
        in_memory=True,
        workers=4,
        max_concurrent_transmissions=2,
    )


async def main() -> None:
    """Concurrent entrypoint running the health-check server and Pyrogram client."""
    config = load_config()
    uploader = GoogleDriveUploader(
        service_account_info=config.service_account_info,
        folder_id=config.gdrive_folder_id,
        chunk_size_bytes=config.upload_chunk_size_bytes,
        share_anyone_with_link=config.share_anyone_with_link,
    )

    app = build_pyrogram_client(config)
    media_filter = (filters.document | filters.video | filters.audio) & filters.private

    @app.on_message(filters.command(["start", "help"]) & filters.private)
    async def start_handler(_client: Client, message: Message) -> None:
        user_id = message.from_user.id if message.from_user else 0
        if config.authorized_user_ids and user_id not in config.authorized_user_ids:
            await message.reply_text(
                f"Access denied. Your Telegram User ID (\`{user_id}\`) is not in \`AUTHORIZED_USER_IDS\`."
            )
            return

        await message.reply_text(
            "**TeleDrive MTProto Bridge Active**\\n\\n"
            "Forward or send any **Document, Video, or Audio** file (up to 2GB) in this private chat.\\n"
            f"• **Upload Chunk Size:** \`{config.upload_chunk_size_mb} MB\` (Resumable)\\n"
            f"• **Destination Folder:** \`{config.gdrive_folder_id or 'Service Account Root'}\`\\n"
            "• **Disk Safety:** Automatic \`finally:\` cleanup after every transfer."
        )

    @app.on_message(media_filter)
    async def handle_media_transfer(client: Client, message: Message) -> None:
        user_id = message.from_user.id if message.from_user else 0
        if config.authorized_user_ids and user_id not in config.authorized_user_ids:
            logger.warning("Unauthorized transfer attempt from user_id=%s", user_id)
            await message.reply_text(
                f"Unauthorized user (\`{user_id}\`). Add your ID to \`AUTHORIZED_USER_IDS\`."
            )
            return

        filename, expected_size = extract_media_metadata(message)
        unique_prefix = f"{message.chat.id}_{message.id}_{int(time.time())}"
        local_file_path = os.path.join(config.download_dir, f"{unique_prefix}_{filename}")
        downloaded_path: Optional[str] = None

        status_msg = await message.reply_text(
            f"**Initializing MTProto Transfer**\\n\\n"
            f"**File:** \`{filename}\`\\n"
            f"**Size:** \`{format_bytes(expected_size)}\`\\n"
            f"**Stage:** Preparing download stream...",
            quote=True,
        )

        try:
            # Stage 1: Stream download from Telegram MTProto to temporary file
            dl_tracker = ThrottledProgressTracker(
                status_message=status_msg,
                filename=filename,
                stage_title="1/2 · Downloading from Telegram (MTProto)",
                min_interval_sec=config.progress_update_interval_sec,
            )

            async def tg_progress(current: int, total: int) -> None:
                await dl_tracker.update(current, total or expected_size)

            downloaded_path = await client.download_media(
                message=message,
                file_name=local_file_path,
                progress=tg_progress,
            )

            if not downloaded_path or not os.path.isfile(downloaded_path):
                raise RuntimeError("Download completed without producing a valid local file.")

            actual_size = os.path.getsize(downloaded_path)
            logger.info("Downloaded '%s' (%d bytes) to %s", filename, actual_size, downloaded_path)

            # Stage 2: Chunked Resumable Upload to Google Drive
            ul_tracker = ThrottledProgressTracker(
                status_message=status_msg,
                filename=filename,
                stage_title=f"2/2 · Uploading to Google Drive ({config.upload_chunk_size_mb}MB Chunks)",
                min_interval_sec=config.progress_update_interval_sec,
            )

            uploaded_file = await uploader.upload_file(
                file_path=downloaded_path,
                filename=filename,
                progress_callback=ul_tracker.update,
            )

            await status_msg.edit_text(
                "**Upload Complete — Saved to Google Drive**\\n\\n"
                f"**Filename:** \`{uploaded_file.name}\`\\n"
                f"**Size:** \`{format_bytes(uploaded_file.size_bytes)}\`\\n"
                f"**Access Mode:** \`{uploaded_file.permission_mode}\`\\n"
                f"**Local Cleanup:** \`Verified (Temp file deleted)\`\\n\\n"
                f"**Google Drive Link:** [Open in Google Drive]({uploaded_file.web_view_link})",
                disable_web_page_preview=False,
            )

        except Exception as exc:
            logger.exception("Transfer failed for '%s': %s", filename, exc)
            try:
                await status_msg.edit_text(
                    f"**Transfer Failed**\\n\\n"
                    f"**File:** \`{filename}\`\\n"
                    f"**Reason:** \`{type(exc).__name__}: {exc}\`\\n"
                    f"**Disk Hygiene:** Local temporary file has been purged."
                )
            except Exception:
                pass
        finally:
            # Crucial Memory & Storage Safety: Always delete temporary file(s)
            for candidate_path in {local_file_path, downloaded_path}:
                if candidate_path and os.path.exists(candidate_path):
                    try:
                        os.remove(candidate_path)
                        logger.info("Deleted temporary file: %s", candidate_path)
                    except OSError as remove_err:
                        logger.error(
                            "Failed to delete temporary file %s: %s",
                            candidate_path,
                            remove_err,
                        )

    # Start aiohttp health server and Pyrogram client concurrently on the same event loop
    health_runner = await start_health_server(config)
    try:
        await app.start()
        me = await app.get_me()
        logger.info(
            "Pyrogram client started as @%s (ID: %s). Listening for private media...",
            getattr(me, "username", None) or "user",
            me.id,
        )
        await idle()
    finally:
        logger.info("Shutting down Pyrogram client and health-check server...")
        try:
            await app.stop()
        except Exception:
            pass
        await health_runner.cleanup()


if __name__ == "__main__":
    asyncio.run(main())
`;

  const dockerfile = `FROM python:3.10-slim

# Prevent Python from writing .pyc files and enable unbuffered logging
ENV PYTHONDONTWRITEBYTECODE=1 \\
    PYTHONUNBUFFERED=1 \\
    PORT=${cfg.port}

# Install build tools required for compiling tgcrypto C extensions if wheel is unavailable
RUN apt-get update && apt-get install -y --no-install-recommends \\
    gcc \\
    python3-dev \\
    && rm -rf /var/lib/apt/lists/*

# Create non-root user with UID ${cfg.nonRootUid} (Mandatory for Hugging Face Spaces)
RUN useradd -m -u ${cfg.nonRootUid} user

USER user
ENV HOME=/home/user \\
    PATH=/home/user/.local/bin:$PATH \\
    DOWNLOAD_DIR=/tmp/teledrive_downloads

WORKDIR $HOME/app

# Install Python dependencies as non-root user
COPY --chown=user:user requirements.txt .
RUN pip install --no-cache-dir --upgrade pip && \\
    pip install --no-cache-dir -r requirements.txt

# Copy project source files
COPY --chown=user:user config.py gdrive.py main.py ./

# Create ephemeral download directory
RUN mkdir -p /tmp/teledrive_downloads

# Expose Hugging Face Spaces standard port
EXPOSE ${cfg.port}

# Start concurrent aiohttp health server + Pyrogram MTProto client
CMD ["python", "main.py"]
`;

  const gitignore = `# Byte-compiled / optimized / DLL files
__pycache__/
*.py[cod]
*$py.class

# Virtual environments
.venv/
venv/
env/

# Pyrogram MTProto session files & SQLite journals (NEVER commit)
*.session
*.session-journal

# Environment secrets & Google Service Account credentials (NEVER commit)
.env
.env.*
!.env.example
*service_account*.json
*credentials*.json
token.json
client_secrets.json

# Ephemeral media downloads directory
downloads/
/tmp/teledrive_downloads/
*.mp4
*.mkv
*.zip
*.rar
*.pdf
*.mp3
*.flac

# IDE & OS metadata
.vscode/
.idea/
.DS_Store
`;

  const readmeMd = `# TeleDrive MTProto — Personal Telegram-to-Google-Drive Bot

A cloud-native Python MTProto bot built with **Pyrogram (v2.x)**, **TgCrypto**, **Google Drive API v3**, and **aiohttp**. Transfers documents, videos, and audio files up to **2GB** directly from Telegram to Google Drive using chunked resumable uploads (\`${cfg.chunkSizeMb}MB\` chunks) while maintaining strict disk safety (\`try...finally\` deletion) and a \`200 OK\` health-check endpoint on port \`${cfg.port}\` for 24/7 hosting on **Hugging Face Spaces** or any Docker runtime.

---

## Architecture Highlights

1. **Native MTProto (Bypasses 20MB Bot API Limit)**: Uses \`pyrogram\` and \`tgcrypto\` to stream files up to 2GB (or 4GB with a UserBot \`SESSION_STRING\`).
2. **Chunked Resumable Google Drive Uploads**: Uses \`MediaFileUpload(..., resumable=True)\` with \`${cfg.chunkSizeMb}MB\` chunks wrapped in \`asyncio.to_thread\` so multi-gigabyte uploads never block the event loop or spike container RAM.
3. **Guaranteed Disk Cleanup (\`finally: os.remove\`)**: Every downloaded file is immediately deleted inside a \`finally:\` block regardless of upload outcome, preventing ephemeral container disk saturation.
4. **Flood-Wait Protected Progress Updates**: Throttles Telegram status edits to once every \`${cfg.progressIntervalSec.toFixed(1)}\` seconds with automatic \`FloodWait\` backoff.
5. **Hugging Face Spaces Ready**: Runs as non-root \`UID ${cfg.nonRootUid}\` and exposes an \`aiohttp\` health endpoint at \`http://0.0.0.0:${cfg.port}/health\`.

---

## Step 1: Prepare Google Service Account & Base64 Secret

1. Open the [Google Cloud Console](https://console.cloud.google.com/), create or select a project, and enable the **Google Drive API**.
2. Go to **IAM & Admin → Service Accounts**, create a Service Account, and generate a **JSON Key** (\`service_account.json\`).
3. **Share Your Target Google Drive Folder**:
   - Create a folder in your personal Google Drive.
   - Share that folder with the Service Account's \`client_email\` (e.g., \`teledrive-bot@your-project.iam.gserviceaccount.com\`) with **Editor** permissions.
   - Copy the Folder ID from the URL (\`https://drive.google.com/drive/folders/<GDRIVE_FOLDER_ID>\`).
4. **Base64-Encode the JSON Key** (so you never commit raw JSON files to Git):
   \`\`\`bash
   # Linux / GNU coreutils
   base64 -w 0 service_account.json

   # macOS / BSD base64
   base64 -i service_account.json | tr -d '\\n'
   \`\`\`

---

## Step 2: Configure Environment Secrets

In **Hugging Face Spaces** (*Settings → Variables and secrets → New secret*) or GitHub / Docker, configure the following secrets:

| Secret Name | Required | Default | Description |
| :--- | :--- | :--- | :--- |
| \`API_ID\` | **Yes** | — | Integer API ID from [my.telegram.org](https://my.telegram.org) |
| \`API_HASH\` | **Yes** | — | 32-character API Hash from [my.telegram.org](https://my.telegram.org) |
| \`BOT_TOKEN\` | **Yes*** | — | Bot token from \`@BotFather\` (*or provide \`SESSION_STRING\` instead*) |
| \`SESSION_STRING\` | Optional | — | Pyrogram MTProto UserBot session string (alternative to \`BOT_TOKEN\`) |
| \`GDRIVE_CREDENTIALS_B64\` | **Yes** | — | Single-line Base64-encoded string of your \`service_account.json\` |
| \`GDRIVE_FOLDER_ID\` | Recommended | \`${cfg.defaultFolderId || 'Root'}\` | Target Google Drive Folder ID shared with the Service Account |
| \`AUTHORIZED_USER_IDS\` | Recommended | \`${cfg.authorizedUserIds || 'None'}\` | Comma-separated Telegram User IDs allowed to use the bot |
| \`UPLOAD_CHUNK_SIZE_MB\` | Optional | \`${cfg.chunkSizeMb}\` | Chunk size in MB for resumable uploads (\`10\` or \`20\`) |

---

## Step 3: Deploy to Hugging Face Spaces (24/7 Free Container)

1. Create a new Space on [Hugging Face](https://huggingface.co/new-space) and select **Docker** as the Space SDK (choose the **Blank** template).
2. Add the secrets listed above in **Settings → Variables and secrets**.
3. Push this repository (\`Dockerfile\`, \`requirements.txt\`, \`config.py\`, \`gdrive.py\`, \`main.py\`, \`.gitignore\`, \`README.md\`) to your Space or sync via a private GitHub repository.
4. Once built, Hugging Face Spaces will probe \`GET :${cfg.port}/\` and mark your container as **Running**. Forward any document, video, or audio file to your bot in a private chat to archive it directly to Google Drive.
`;

  const envExample = `# ============================================================================
# TeleDrive MTProto — Environment Configuration Template (.env.example)
# Copy to .env for local testing or configure as Secrets in Hugging Face Spaces
# ============================================================================

# 1. Telegram MTProto Credentials (https://my.telegram.org)
API_ID=12345678
API_HASH=0123456789abcdef0123456789abcdef

# 2. Authentication Mode (Set BOT_TOKEN or SESSION_STRING)
${
  cfg.authMode === 'session_string'
    ? '# BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrSTUvwxYZ\nSESSION_STRING=BQAA...your_pyrogram_mtproto_session_string'
    : 'BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrSTUvwxYZ\n# SESSION_STRING='
}

# 3. Access Control (Comma-separated Telegram User IDs allowed to transfer files)
AUTHORIZED_USER_IDS=${cfg.authorizedUserIds || '123456789'}

# 4. Google Drive Destination & Base64 Service Account JSON
GDRIVE_FOLDER_ID=${cfg.defaultFolderId || '1A2B3C4D5E6F7G8H9I0J_folder_id'}
GDRIVE_CREDENTIALS_B64=${cfg.base64CredentialsPreview || 'eyJ0eXBlIjogInNlcnZpY2VfYWNjb3VudCIsICJwcm9qZWN0X2lkIjogInRlbGVkcml2ZS1hcmNoaXZlIn0='}
GDRIVE_PUBLIC_LINK=${cfg.sharePublicLink ? 'true' : 'false'}

# 5. Transfer Tuning & Health Check Server
UPLOAD_CHUNK_SIZE_MB=${cfg.chunkSizeMb}
PROGRESS_UPDATE_INTERVAL=${cfg.progressIntervalSec.toFixed(1)}
PORT=${cfg.port}
`;

  return [
    {
      id: 'main.py',
      filename: 'main.py',
      category: 'Core Python',
      language: 'python',
      summary: `Asyncio entrypoint running aiohttp health server (Port ${cfg.port}) + Pyrogram MTProto media handler with ${cfg.progressIntervalSec.toFixed(1)}s throttled progress and finally: os.remove() cleanup.`,
      highlights: [
        `Concurrent asyncio loop: aiohttp (:7860) + Pyrogram Client`,
        `Filter: (filters.document | filters.video | filters.audio) & filters.private`,
        `FloodWait-safe progress tracker throttled to ${cfg.progressIntervalSec.toFixed(1)}s`,
        `Guaranteed os.remove(file_path) inside finally: block`,
      ],
      content: mainPy,
    },
    {
      id: 'gdrive.py',
      filename: 'gdrive.py',
      category: 'Core Python',
      language: 'python',
      summary: `Modular Google Drive API v3 client using Base64-decoded Service Account credentials and ${cfg.chunkSizeMb}MB chunked resumable MediaFileUpload.`,
      highlights: [
        `MediaFileUpload(resumable=True, chunksize=${cfg.chunkSizeMb} * 1024 * 1024)`,
        `Non-blocking asyncio.to_thread(request.next_chunk) execution`,
        `Returns structured file metadata including webViewLink`,
      ],
      content: gdrivePy,
    },
    {
      id: 'config.py',
      filename: 'config.py',
      category: 'Core Python',
      language: 'python',
      summary: `Strict environment variable loader decoding GDRIVE_CREDENTIALS_B64 in-memory and validating API_ID, API_HASH, BOT_TOKEN / SESSION_STRING, and AUTHORIZED_USER_IDS.`,
      highlights: [
        `In-memory Base64 decoding for GDRIVE_CREDENTIALS_B64`,
        `Supports both BOT_TOKEN and UserBot SESSION_STRING`,
        `Parses AUTHORIZED_USER_IDS allowlist`,
      ],
      content: configPy,
    },
    {
      id: 'requirements.txt',
      filename: 'requirements.txt',
      category: 'Container & Deps',
      language: 'text',
      summary: `Pinned production dependencies for Pyrogram 2.x, TgCrypto, Google Drive API v3, and aiohttp.`,
      highlights: [
        `pyrogram==2.0.106 & tgcrypto==1.2.5`,
        `google-api-python-client==2.149.0 & google-auth==2.35.0`,
        `aiohttp==3.10.10`,
      ],
      content: requirementsTxt,
    },
    {
      id: 'Dockerfile',
      filename: 'Dockerfile',
      category: 'Container & Deps',
      language: 'dockerfile',
      summary: `Lightweight python:3.10-slim image configured with non-root user UID ${cfg.nonRootUid} and port ${cfg.port} for Hugging Face Spaces.`,
      highlights: [
        `Base image: python:3.10-slim with gcc for tgcrypto`,
        `Non-root user creation: useradd -m -u ${cfg.nonRootUid} user`,
        `Exposes port ${cfg.port} and starts python main.py`,
      ],
      content: dockerfile,
    },
    {
      id: '.gitignore',
      filename: '.gitignore',
      category: 'Docs & Git',
      language: 'text',
      summary: `Prevents Pyrogram .session files, SQLite journals, Service Account JSON keys, and ephemeral downloads from ever being committed.`,
      highlights: [
        `Blocks *.session and *.session-journal`,
        `Blocks *service_account*.json and .env secrets`,
        `Excludes temporary media download directories`,
      ],
      content: gitignore,
    },
    {
      id: 'README.md',
      filename: 'README.md',
      category: 'Docs & Git',
      language: 'markdown',
      summary: `Step-by-step deployment documentation for Base64 Service Account encoding, Google Drive folder sharing, and Hugging Face Spaces secrets.`,
      highlights: [
        `Base64 encoding commands for Linux & macOS`,
        `Service Account folder sharing instructions`,
        `Hugging Face Spaces Docker deployment checklist`,
      ],
      content: readmeMd,
    },
    {
      id: '.env.example',
      filename: '.env.example',
      category: 'Docs & Git',
      language: 'text',
      summary: `Ready-to-use environment variable template pre-populated with your configured runtime parameters.`,
      highlights: [
        `Pre-filled with your chunk size, throttle interval, and port`,
        `Includes GDRIVE_CREDENTIALS_B64 from the Base64 Studio`,
      ],
      content: envExample,
    },
  ];
}
