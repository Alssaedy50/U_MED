import React, { useState, useEffect } from 'react';
import { Play, RotateCcw, ShieldCheck, Trash2, ExternalLink } from 'lucide-react';

interface TransferSimulatorProps {
  chunkSizeMb: 10 | 20;
  progressIntervalSec: number;
  folderId: string;
}

type SimStage = 'idle' | 'downloading' | 'uploading' | 'cleanup_complete';

export const TransferSimulator: React.FC<TransferSimulatorProps> = ({
  chunkSizeMb,
  progressIntervalSec,
  folderId,
}) => {
  const [sampleSizeMb, setSampleSizeMb] = useState<number>(1480); // 1.48 GB sample video
  const [stage, setStage] = useState<SimStage>('idle');
  const [transferredMb, setTransferredMb] = useState<number>(0);
  const [logs, setLogs] = useState<string[]>([
    'GET /health -> 200 OK {"status": "OK", "service": "teledrive-mtproto-bot", "port": 7860}',
    'Pyrogram MTProto client listening for (filters.document | filters.video | filters.audio) & filters.private',
  ]);

  useEffect(() => {
    if (stage !== 'downloading' && stage !== 'uploading') return;

    const timer = setInterval(() => {
      setTransferredMb((prev) => {
        const increment = stage === 'downloading' ? 185 : chunkSizeMb * 8;
        const next = prev + increment;

        if (next >= sampleSizeMb) {
          if (stage === 'downloading') {
            setStage('uploading');
            setLogs((l) => [
              ...l,
              `Downloaded 'production_4k_master_archive.mkv' (${sampleSizeMb} MB) to /tmp/teledrive_downloads/`,
              `Starting Google Drive MediaFileUpload (resumable=True, chunksize=${chunkSizeMb}MB) via asyncio.to_thread...`,
            ]);
            return 0;
          } else {
            setStage('cleanup_complete');
            setLogs((l) => [
              ...l,
              `Google Drive upload complete -> File ID: 1x9K_drive_archive_8821`,
              `finally: os.remove('/tmp/teledrive_downloads/production_4k_master_archive.mkv') executed -> Ephemeral disk freed (0 B leaked)`,
            ]);
            return sampleSizeMb;
          }
        }
        return next;
      });
    }, 450);

    return () => clearInterval(timer);
  }, [stage, sampleSizeMb, chunkSizeMb]);

  const startSimulation = () => {
    setTransferredMb(0);
    setStage('downloading');
    setLogs([
      'GET /health -> 200 OK {"status": "OK", "service": "teledrive-mtproto-bot", "port": 7860}',
      `Incoming private video from authorized user -> 'production_4k_master_archive.mkv' (${sampleSizeMb} MB)`,
      `Streaming MTProto chunks (Telegram status edits throttled to every ${progressIntervalSec.toFixed(1)}s)...`,
    ]);
  };

  const resetSimulation = () => {
    setStage('idle');
    setTransferredMb(0);
    setLogs([
      'GET /health -> 200 OK {"status": "OK", "service": "teledrive-mtproto-bot", "port": 7860}',
      'Pyrogram MTProto client listening for (filters.document | filters.video | filters.audio) & filters.private',
    ]);
  };

  const percent = Math.min(100, Math.round((transferredMb / sampleSizeMb) * 100));
  const filledBlocks = Math.round((percent / 100) * 12);
  const asciiBar = '█'.repeat(filledBlocks) + '░'.repeat(12 - filledBlocks);
  const currentChunkIndex = Math.ceil(transferredMb / chunkSizeMb);
  const totalChunks = Math.ceil(sampleSizeMb / chunkSizeMb);

  return (
    <div className="border border-slate-800 bg-slate-900/60 rounded-lg p-5 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-100">
            MTProto Transfer & Ephemeral Disk Cleanup Simulator
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Preview the exact Telegram status message output, {chunkSizeMb}MB resumable chunk progression, and{' '}
            <code className="text-slate-300">finally: os.remove()</code> disk hygiene.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-md p-1">
            {[650, 1480, 1950].map((size) => (
              <button
                key={size}
                type="button"
                disabled={stage === 'downloading' || stage === 'uploading'}
                onClick={() => setSampleSizeMb(size)}
                className={`px-2.5 py-1 text-xs font-mono tabular-nums rounded transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  sampleSizeMb === size
                    ? 'bg-slate-800 text-slate-100 font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {(size / 1024).toFixed(2)} GB
              </button>
            ))}
          </div>

          {stage === 'idle' ? (
            <button
              type="button"
              onClick={startSimulation}
              className="px-3.5 py-1.5 text-xs font-medium bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Simulate 1.45 GB Transfer</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={resetSimulation}
              className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Simulated Telegram Bot Reply Message */}
        <div className="border border-slate-800 bg-slate-950 rounded-md p-4 font-mono text-xs space-y-2">
          <div className="flex items-center justify-between text-slate-400 border-b border-slate-800/80 pb-2">
            <span>Telegram Private Chat Preview</span>
            <span className="tabular-nums">
              Edit Throttle: {progressIntervalSec.toFixed(1)}s
            </span>
          </div>

          {stage === 'idle' && (
            <div className="py-4 text-slate-400 space-y-1">
              <p className="text-slate-200 font-semibold">TeleDrive MTProto Bridge Active</p>
              <p>Forward any Document, Video, or Audio file (up to 2GB) in private chat.</p>
              <p className="text-slate-500">
                Click "Simulate 1.45 GB Transfer" above to preview the live progress tracker.
              </p>
            </div>
          )}

          {(stage === 'downloading' || stage === 'uploading') && (
            <div className="py-2 space-y-1.5 text-slate-200">
              <p className="font-semibold text-sky-300">
                {stage === 'downloading'
                  ? '1/2 · Downloading from Telegram (MTProto)'
                  : `2/2 · Uploading to Google Drive (${chunkSizeMb}MB Chunks)`}
              </p>
              <p>
                <span className="text-slate-400">File:</span>{' '}
                <span className="text-slate-100">production_4k_master_archive.mkv</span>
              </p>
              <p className="tabular-nums">
                <span className="text-slate-400">Progress:</span>{' '}
                <span className="text-sky-400">{asciiBar}</span>{' '}
                <span>{percent.toFixed(1)}%</span>
              </p>
              <p className="tabular-nums">
                <span className="text-slate-400">Transferred:</span>{' '}
                <span>
                  {transferredMb.toFixed(0)} MB / {sampleSizeMb} MB
                </span>
                {stage === 'uploading' && (
                  <span className="text-slate-400">
                    {' '}
                    · Chunk {currentChunkIndex}/{totalChunks}
                  </span>
                )}
              </p>
              <p className="tabular-nums text-slate-400">
                Speed: 42.50 MB/s · ETA:{' '}
                {Math.max(1, Math.round((sampleSizeMb - transferredMb) / 42.5))}s
              </p>
            </div>
          )}

          {stage === 'cleanup_complete' && (
            <div className="py-2 space-y-1.5 text-slate-200">
              <p className="font-semibold text-emerald-400">
                Upload Complete — Saved to Google Drive
              </p>
              <p>
                <span className="text-slate-400">Filename:</span>{' '}
                <span>production_4k_master_archive.mkv</span>
              </p>
              <p className="tabular-nums">
                <span className="text-slate-400">Size:</span>{' '}
                <span>{(sampleSizeMb / 1024).toFixed(2)} GB</span> ·{' '}
                <span className="text-slate-400">Folder:</span>{' '}
                <span>{folderId || 'Root'}</span>
              </p>
              <p className="flex items-center gap-1.5 text-emerald-300">
                <Trash2 className="w-3.5 h-3.5" />
                <span>Local Cleanup: Verified (Temp file deleted via finally:)</span>
              </p>
              <p className="pt-1">
                <span className="text-sky-400 underline inline-flex items-center gap-1">
                  <span>https://drive.google.com/file/d/1x9K_drive_archive_8821/view</span>
                  <ExternalLink className="w-3 h-3" />
                </span>
              </p>
            </div>
          )}
        </div>

        {/* Container Runtime Log Stream */}
        <div className="border border-slate-800 bg-slate-950 rounded-md p-4 font-mono text-xs flex flex-col justify-between">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-slate-400 border-b border-slate-800/80 pb-2">
              <span>Container Event Loop Trace (UID 1000 · Port 7860)</span>
              <span className="flex items-center gap-1 text-emerald-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Zero-Leak Guaranteed</span>
              </span>
            </div>
            <div className="space-y-1.5 pt-1 max-h-36 overflow-y-auto">
              {logs.map((entry, idx) => (
                <div key={idx} className="text-slate-300 leading-relaxed">
                  <span className="text-slate-500 select-none mr-2 tabular-nums">
                    [{String(idx + 1).padStart(2, '0')}]
                  </span>
                  <span>{entry}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
