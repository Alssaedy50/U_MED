import React, { useState } from 'react';
import { Check, Copy, Upload, KeyRound, AlertTriangle, FileJson } from 'lucide-react';

interface ServiceAccountEncoderProps {
  onEncodedChange: (b64: string, clientEmail?: string) => void;
}

const SAMPLE_SERVICE_ACCOUNT = JSON.stringify(
  {
    type: 'service_account',
    project_id: 'teledrive-cloud-archive',
    private_key_id: '8f9a2b4c1d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a',
    private_key: '-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC7...\n-----END PRIVATE KEY-----\n',
    client_email: 'teledrive-worker@teledrive-cloud-archive.iam.gserviceaccount.com',
    client_id: '104928374659182736450',
    auth_uri: 'https://accounts.google.com/o/oauth2/auth',
    token_uri: 'https://oauth2.googleapis.com/token',
    auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
    client_x509_cert_url: 'https://www.googleapis.com/robot/v1/metadata/x509/teledrive-worker',
  },
  null,
  2
);

function encodeUtf8ToBase64(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export const ServiceAccountEncoder: React.FC<ServiceAccountEncoderProps> = ({
  onEncodedChange,
}) => {
  const [rawJson, setRawJson] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [parsedMeta, setParsedMeta] = useState<{
    projectId: string;
    clientEmail: string;
    keyId: string;
    b64Output: string;
  } | null>(null);
  const [copiedB64, setCopiedB64] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);

  const processJsonInput = (input: string) => {
    setRawJson(input);
    if (!input.trim()) {
      setError(null);
      setParsedMeta(null);
      onEncodedChange('');
      return;
    }

    try {
      const parsed = JSON.parse(input);
      const requiredFields = ['type', 'project_id', 'private_key', 'client_email'];
      const missing = requiredFields.filter((k) => !parsed[k]);

      if (missing.length > 0) {
        setError(`Missing required Service Account keys: ${missing.join(', ')}`);
        setParsedMeta(null);
        return;
      }

      if (parsed.type !== 'service_account') {
        setError(`Expected "type": "service_account", found "${parsed.type}".`);
        setParsedMeta(null);
        return;
      }

      // Minify JSON before Base64 encoding to keep env secret compact
      const compactJson = JSON.stringify(parsed);
      const b64 = encodeUtf8ToBase64(compactJson);

      setError(null);
      setParsedMeta({
        projectId: parsed.project_id,
        clientEmail: parsed.client_email,
        keyId: parsed.private_key_id || 'N/A',
        b64Output: b64,
      });
      onEncodedChange(b64, parsed.client_email);
    } catch {
      setError('Invalid JSON syntax. Paste the complete contents of your service_account.json file.');
      setParsedMeta(null);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = typeof event.target?.result === 'string' ? event.target.result : '';
      processJsonInput(content);
    };
    reader.readAsText(file);
  };

  const copyBase64 = async () => {
    if (!parsedMeta?.b64Output) return;
    await navigator.clipboard.writeText(parsedMeta.b64Output);
    setCopiedB64(true);
    setTimeout(() => setCopiedB64(false), 1800);
  };

  const copyClientEmail = async () => {
    if (!parsedMeta?.clientEmail) return;
    await navigator.clipboard.writeText(parsedMeta.clientEmail);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 1800);
  };

  return (
    <div className="border border-slate-800 bg-slate-900/60 rounded-lg p-5 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-100">
            Service Account Base64 Encoder (GDRIVE_CREDENTIALS_B64)
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Encodes your Google Cloud Service Account JSON strictly in browser memory so raw credential files are never committed to GitHub.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => processJsonInput(SAMPLE_SERVICE_ACCOUNT)}
            className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Load Sample JSON
          </button>
          <label className="px-3 py-1.5 text-xs font-medium text-sky-300 bg-sky-500/10 border border-sky-500/30 hover:bg-sky-500/20 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload JSON File</span>
            <input
              type="file"
              accept=".json,application/json"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Raw service_account.json Input</span>
            {rawJson && (
              <button
                type="button"
                onClick={() => processJsonInput('')}
                className="text-slate-400 hover:text-slate-200 underline cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
          <textarea
            value={rawJson}
            onChange={(e) => processJsonInput(e.target.value)}
            placeholder='Paste your Google Cloud Service Account JSON here ({"type": "service_account", ...})'
            rows={6}
            className="w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-xs font-mono text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-sky-500"
          />
        </div>

        <div className="space-y-3 flex flex-col justify-between">
          {error ? (
            <div className="border border-amber-500/40 bg-amber-500/10 rounded-md p-3 text-xs text-amber-200 flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-amber-100">Credential Validation Error</p>
                <p className="mt-1 text-amber-200/90">{error}</p>
              </div>
            </div>
          ) : parsedMeta ? (
            <div className="space-y-3">
              <div className="border border-emerald-500/30 bg-emerald-500/5 rounded-md p-3 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-emerald-300">
                    Validated Service Account Metadata
                  </span>
                  <span className="text-slate-400 font-mono tabular-nums">
                    {parsedMeta.b64Output.length} chars
                  </span>
                </div>
                <div className="text-xs text-slate-300 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-400">Project ID:</span>
                    <span className="font-mono text-slate-200 truncate">
                      {parsedMeta.projectId}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-400 shrink-0">Service Email:</span>
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="font-mono text-sky-300 truncate">
                        {parsedMeta.clientEmail}
                      </span>
                      <button
                        type="button"
                        onClick={copyClientEmail}
                        title="Copy Service Account email to share your Google Drive folder with"
                        className="p-1 text-slate-400 hover:text-slate-100 bg-slate-800/80 rounded cursor-pointer shrink-0"
                      >
                        {copiedEmail ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">
                    Encoded <code className="text-slate-200">GDRIVE_CREDENTIALS_B64</code> Secret
                  </span>
                  <button
                    type="button"
                    onClick={copyBase64}
                    className="px-2.5 py-1 text-xs font-medium bg-sky-500 hover:bg-sky-400 text-slate-950 rounded transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
                  >
                    {copiedB64 ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Copied Secret</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Base64 String</span>
                      </>
                    )}
                  </button>
                </div>
                <input
                  type="text"
                  readOnly
                  value={parsedMeta.b64Output}
                  className="w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-xs font-mono text-emerald-300 focus:outline-none"
                />
              </div>
            </div>
          ) : (
            <div className="h-full border border-dashed border-slate-800 rounded-md p-4 flex flex-col items-center justify-center text-center">
              <FileJson className="w-6 h-6 text-slate-500 mb-2" />
              <p className="text-xs font-medium text-slate-300">
                No Service Account JSON Loaded
              </p>
              <p className="text-xs text-slate-500 mt-1 max-w-sm">
                Paste your <code className="text-slate-400">service_account.json</code> or click{' '}
                <strong className="text-slate-400">Load Sample JSON</strong> to inspect how{' '}
                <code className="text-slate-400">config.py</code> decodes credentials at runtime.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
